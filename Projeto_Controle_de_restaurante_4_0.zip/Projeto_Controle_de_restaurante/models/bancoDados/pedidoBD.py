# Relacionamento "Pede": um cliente (cpf) faz pedidos, e cada pedido tem vários pratos.
# "itens" é a lista de códigos de prato; o mesmo código pode repetir (ex.: 2 sucos)
listaPedidos = [
{
    "codigo": 1,
    "cpf": "12345678909",
    "itens": ["1", "2"],
},
{
    "codigo": 2,
    "cpf": "98765432100",
    "itens": ["3"],
},
]

def encontrar_pedido(codigo):
    indice = 0
    for item in listaPedidos:
        if item["codigo"] == codigo:
            return indice
        indice += 1

    return None

def pegarListaPedidos():
    return listaPedidos

def gerarCodigoPedido():
    maior = 0
    for item in listaPedidos:
        if item["codigo"] > maior:
            maior = item["codigo"]
    return maior + 1

# Retorna o código do pedido criado
def adicionarPedido(cpf, itens):
    codigo = gerarCodigoPedido()
    pedido = {"codigo": codigo,
              "cpf": cpf,
              "itens": list(itens)
              }
    listaPedidos.append(pedido)
    return codigo

def removerPedido(indiceExcluir):
    listaPedidos.pop(indiceExcluir)

def clienteTemPedidos(cpf):
    for item in listaPedidos:
        if item["cpf"] == cpf:
            return True

    return False

def pratoTemPedidos(codigoPrato):
    for item in listaPedidos:
        if codigoPrato in item["itens"]:
            return True

    return False
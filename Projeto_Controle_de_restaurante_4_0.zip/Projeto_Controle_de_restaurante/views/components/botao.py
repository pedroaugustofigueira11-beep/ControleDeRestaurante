import flet as ft

# Botão padrão do sistema: cor de fundo, ícone e texto brancos, cantos arredondados.
# Quando "grande" é True o botão fica alto, com texto maior e ocupa todo o espaço da linha (expand)
def criarBotao(texto, icone, cor, aoClicar, dados=None, grande=False):
    if grande:
        conteudo = ft.Text(texto, size=22, weight=ft.FontWeight.BOLD, color=ft.Colors.WHITE)
        altura = 50
    else:
        conteudo = texto
        altura = None

    botao = ft.Button(content=conteudo,
                      icon=icone,
                      style=ft.ButtonStyle(bgcolor=cor,
                                           color=ft.Colors.WHITE,
                                           icon_color=ft.Colors.WHITE,
                                           shape=ft.RoundedRectangleBorder(radius=10)),
                      height=altura,
                      expand=grande,
                      on_click=aoClicar,
                      data=dados)
    return botao

# Alterar = azul | Remover e Cancelar = vermelho
def criarBotaoAlterar(aoClicar, dados=None, grande=False):
    return criarBotao("Alterar", ft.Icons.EDIT, ft.Colors.BLUE_700, aoClicar, dados, grande)

def criarBotaoRemover(aoClicar, dados=None):
    return criarBotao("Remover", ft.Icons.DELETE, ft.Colors.RED_700, aoClicar, dados)

def criarBotaoCancelar(aoClicar, dados=None, grande=False):
    return criarBotao("Cancelar", ft.Icons.CANCEL, ft.Colors.RED_700, aoClicar, dados, grande)

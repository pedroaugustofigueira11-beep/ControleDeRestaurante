import flet as ft

def criarTitulo(texto):
    titulo = ft.Container(content=ft.Text(texto, size=30, weight=ft.FontWeight.BOLD, color=ft.Colors.ORANGE),
                          alignment=ft.Alignment.CENTER)
    return titulo

# O "data" guarda o rótulo original, para voltar ao normal depois de uma mensagem de erro
def criarCampo(rotulo, aoDigitar=None, valor="", icone=None, dica=None):
    campo = ft.TextField(label=rotulo, data=rotulo,
                         value=valor,
                         prefix_icon=icone,
                         hint_text=dica,
                         border_color=ft.Colors.WHITE,
                         border_radius=10,
                         text_size=18,
                         on_change=aoDigitar)
    return campo

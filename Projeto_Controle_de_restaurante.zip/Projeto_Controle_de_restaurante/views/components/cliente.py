import flet as ft
import models.utilidades as ut

def criarCliente(nome, cpf, email, telefone, linhasBotao = None):
    textoNome = ft.Text(nome, size=20, weight=ft.FontWeight.BOLD)
    textoCpf = ft.Text(f"CPF: {ut.formatarCpf(cpf)}")
    textoEmail = ft.Text(f"E-mail: {email}")
    textoTelefone = ft.Text(f"Telefone: {ut.formatarTelefone(telefone)}")

    listaElementos = [textoNome, textoCpf, textoEmail, textoTelefone]
    if linhasBotao != None:
        listaElementos.append(linhasBotao)

    clienteModelo = ft.Container(content=ft.Column(controls=listaElementos),
                                 border=ft.Border.all(1, ft.Colors.ORANGE),
                                 padding=15,
                                 margin=10)

    return clienteModelo

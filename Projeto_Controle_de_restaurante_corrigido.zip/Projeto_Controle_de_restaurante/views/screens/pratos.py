import flet as ft
import views.components.campo as ct
import views.components.prato as ctPrato
import models
import views.menu as menu

def abrirTelaAlterar(e: ft.Event[ft.Button]):
    codigoPrato = e.control.data[0]
    estruturaPagina = e.control.data[1]

    menu.ao_mudar_aba(estruturaPagina, 4, codigoPrato)

def ladoCadastro(estruturaPagina, mensagem):
    titulo = ct.criarTitulo("Cadastro de Prato")

    campoCodigo = ct.criarCampo("Código do prato", models.verificarCodigoDigitado)
    campoNome = ct.criarCampo("Nome", models.verificarNomePratoDigitado)
    campoCategoria = ct.criarCampo("Categoria (Entrada, Prato Principal, Sobremesa, Bebida)", models.verificarCategoriaDigitada)
    campoPreco = ct.criarCampo("Preço (ex: 25,90)", models.verificarPrecoDigitado)
    campoTempo = ct.criarCampo("Tempo de preparo (minutos)", models.verificarTempoDigitado)

    textoMensagens = ft.Text(mensagem, size=18, color=ft.Colors.GREEN)

    botao = ft.Button(content="Cadastrar", icon=ft.Icons.ADD,
                      on_click=models.cadastrarPrato,
                      data=[campoCodigo, campoNome, campoCategoria, campoPreco, campoTempo, textoMensagens, estruturaPagina])

    linhaBotao = ft.Row(controls=[textoMensagens, botao], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)

    colunaCadastro = ft.Container(content=ft.Column(controls=[titulo, ct.criarBlocoCampo(campoCodigo), ct.criarBlocoCampo(campoNome),
                                                              ct.criarBlocoCampo(campoCategoria), ct.criarBlocoCampo(campoPreco),
                                                              ct.criarBlocoCampo(campoTempo), linhaBotao],
                                                    horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                                                    scroll=ft.ScrollMode.AUTO),
                                  expand=True,
                                  padding=20)

    return colunaCadastro

def ladoLista(estruturaPagina):
    titulo = ct.criarTitulo("Pratos Cadastrados")

    dialogo = ft.AlertDialog(   modal=False,
                                title=ft.Text("Aviso Importante"),
                                content=ft.Text(""),
                                actions_alignment=ft.MainAxisAlignment.END)

    listElementosColunaPrato = [titulo]
    for prato in models.pegarListaPratos():
        botaoAlterar = ft.Button(content="Alterar", icon=ft.Icons.EDIT,
                                 on_click=abrirTelaAlterar,
                                 data=[prato['codigo'], estruturaPagina])
        botaoRemover = ft.Button(content="Remover", icon=ft.Icons.REMOVE,
                                 on_click=models.verificarCondicoesDeExclusaoPrato,
                                 data=[prato['codigo'], dialogo, estruturaPagina])
        linhaBotoes = ft.Row(controls=[botaoAlterar, botaoRemover], alignment=ft.MainAxisAlignment.END)

        pratoModelo = ctPrato.criarPrato(prato['codigo'], prato['nome'], prato['categoria'],
                                         prato['preco'], prato['tempoPreparo'],
                                         linhaBotoes)
        listElementosColunaPrato.append(pratoModelo)

    colunaPratos = ft.Container(content=ft.Column(controls=listElementosColunaPrato,
                                                  horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                                                  scroll=ft.ScrollMode.AUTO),
                                expand=True,
                                padding=20)

    return colunaPratos

def telaPratos(estruturaPagina=None, mensagem=None):
    if mensagem == None:
        mensagem = ""

    telaLadoCadastro = ladoCadastro(estruturaPagina, mensagem)
    telaLadoLista = ladoLista(estruturaPagina)

    divisoriaVertical = ft.VerticalDivider(1, color=ft.Colors.GREY)

    divisaoTela = ft.Row(controls=[telaLadoCadastro, divisoriaVertical, telaLadoLista], expand=True)
    tela = ft.Container(content=divisaoTela, expand=True)

    return tela

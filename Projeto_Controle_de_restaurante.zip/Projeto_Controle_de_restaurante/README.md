# Controle de Restaurante

Projeto CRUD em Python + Flet com 3 telas: Clientes, Pratos e Pedidos (relacionamento "Pede").
Estrutura no mesmo padrão do projeto Bingo: `views/` (telas e componentes) e `models/` (regras e dados em listas).

Para rodar: `pip install flet` e depois `python main.py`

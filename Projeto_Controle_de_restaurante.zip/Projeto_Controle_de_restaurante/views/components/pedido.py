import flet as ft
import models.utilidades as ut

def criarPedido(codigo, nomeCliente, cpf, nomePrato, preco, tempoPreparo, linhasBotao = None):
    textoCodigo = ft.Text(f"Pedido nº {codigo}", size=20, weight=ft.FontWeight.BOLD)
    textoCliente = ft.Text(f"Cliente: {nomeCliente} (CPF {ut.formatarCpf(cpf)})")
    textoPrato = ft.Text(f"Prato: {nomePrato}")
    textoValores = ft.Text(f"Preço: {ut.formatarPreco(preco)} | Preparo: {tempoPreparo} min")

    listaElementos = [textoCodigo, textoCliente, textoPrato, textoValores]
    if linhasBotao != None:
        listaElementos.append(linhasBotao)

    pedidoModelo = ft.Container(content=ft.Column(controls=listaElementos),
                                border=ft.Border.all(1, ft.Colors.ORANGE),
                                padding=15,
                                margin=10)

    return pedidoModelo

import flet as ft
import views.components.campo as ct
import views.components.pedido as ctPedido
import models

def ladoCadastro(estruturaPagina, mensagem):
    titulo = ct.criarTitulo("Novo Pedido")

    dica = ft.Text("Use o CPF da aba Clientes e o código da aba Pratos")

    campoCpf = ct.criarCampo("CPF do cliente", models.verificarCpfDigitado)
    campoCodigo = ct.criarCampo("Código do prato", models.verificarCodigoDigitado)

    textoMensagens = ft.Text(mensagem, size=18, color=ft.Colors.GREEN)

    botao = ft.Button(content="Registrar Pedido", icon=ft.Icons.ADD,
                      on_click=models.cadastrarPedido,
                      data=[campoCpf, campoCodigo, textoMensagens, estruturaPagina])

    linhaBotao = ft.Row(controls=[textoMensagens, botao], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)

    colunaCadastro = ft.Container(content=ft.Column(controls=[titulo, dica, campoCpf, campoCodigo, linhaBotao],
                                                    scroll=ft.ScrollMode.AUTO),
                                  expand=True,
                                  padding=20)

    return colunaCadastro

def ladoLista(estruturaPagina):
    titulo = ct.criarTitulo("Pedidos Registrados")

    dialogo = ft.AlertDialog(   modal=False,
                                title=ft.Text("Aviso Importante"),
                                content=ft.Text(""),
                                actions_alignment=ft.MainAxisAlignment.END)

    listElementosColunaPedido = [titulo]
    for pedido in models.pegarListaPedidos():
        botaoRemover = ft.Button(content="Remover", icon=ft.Icons.REMOVE,
                                 on_click=models.verificarCondicoesDeExclusaoPedido,
                                 data=[pedido['codigo'], dialogo, estruturaPagina])
        linhaBotoes = ft.Row(controls=[botaoRemover], alignment=ft.MainAxisAlignment.END)

        pedidoModelo = ctPedido.criarPedido(pedido['codigo'], pedido['nomeCliente'], pedido['cpf'],
                                            pedido['nomePrato'], pedido['preco'], pedido['tempoPreparo'],
                                            linhaBotoes)
        listElementosColunaPedido.append(pedidoModelo)

    colunaPedidos = ft.Container(content=ft.Column(controls=listElementosColunaPedido,
                                                   horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                                                   scroll=ft.ScrollMode.AUTO),
                                 expand=True,
                                 padding=20)

    return colunaPedidos

def telaPedidos(estruturaPagina=None, mensagem=None):
    if mensagem == None:
        mensagem = ""

    telaLadoCadastro = ladoCadastro(estruturaPagina, mensagem)
    telaLadoLista = ladoLista(estruturaPagina)

    divisoriaVertical = ft.VerticalDivider(1, color=ft.Colors.GREY)

    divisaoTela = ft.Row(controls=[telaLadoCadastro, divisoriaVertical, telaLadoLista], expand=True)
    tela = ft.Container(content=divisaoTela, expand=True)

    return tela

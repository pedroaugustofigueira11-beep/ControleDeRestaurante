import flet as ft
import views.components.campo as ct
import views.components.cliente as ctCliente
import models
import views.menu as menu

def abrirTelaAlterar(e: ft.Event[ft.Button]):
    cpfCliente = e.control.data[0]
    estruturaPagina = e.control.data[1]

    menu.ao_mudar_aba(estruturaPagina, 3, cpfCliente)

def ladoCadastro(estruturaPagina, mensagem):
    titulo = ct.criarTitulo("Cadastro de Cliente")

    campoNome = ct.criarCampo("Nome", models.verificarNomeClienteDigitado)
    campoCpf = ct.criarCampo("CPF (somente números)", models.verificarCpfDigitado)
    campoEmail = ct.criarCampo("E-mail", models.verificarEmailDigitado)
    campoTelefone = ct.criarCampo("Telefone com DDD", models.verificarTelefoneDigitado)

    textoMensagens = ft.Text(mensagem, size=18, color=ft.Colors.GREEN)

    botao = ft.Button(content=ft.Text("Cadastrar", size=22, weight=ft.FontWeight.BOLD),
                      icon=ft.Icons.ADD,
                      height=50,
                      expand=True,
                      on_click=models.cadastrarCliente,
                      data=[campoNome, campoCpf, campoEmail, campoTelefone, textoMensagens, estruturaPagina])

    linhaMensagem = ft.Row(controls=[textoMensagens], alignment=ft.MainAxisAlignment.CENTER)
    linhaBotao = ft.Row(controls=[botao], alignment=ft.MainAxisAlignment.CENTER)
    colunaCampos = ft.Column(controls=[campoNome, campoCpf, campoEmail, campoTelefone], alignment=ft.MainAxisAlignment.CENTER)
    LinhacolunaCampos = ft.Row(controls=[colunaCampos], alignment=ft.MainAxisAlignment.CENTER)

    colunaCadastro = ft.Container(content=ft.Column(controls=[titulo, LinhacolunaCampos, linhaBotao, linhaMensagem],
                                                    scroll=ft.ScrollMode.AUTO),
                                  expand=True,
                                  padding=20)

    return colunaCadastro

def ladoLista(estruturaPagina):
    titulo = ct.criarTitulo("Clientes Cadastrados")

    dialogo = ft.AlertDialog(   modal=False,
                                title=ft.Text("Aviso Importante"),
                                content=ft.Text(""),
                                actions_alignment=ft.MainAxisAlignment.END)

    listElementosColunaCliente = [titulo]
    for cliente in models.pegarListaClientes():
        botaoAlterar = ft.Button(content="Alterar", icon=ft.Icons.EDIT,
                                 on_click=abrirTelaAlterar,
                                 data=[cliente['cpf'], estruturaPagina])
        botaoRemover = ft.Button(content="Remover", icon=ft.Icons.REMOVE,
                                 on_click=models.verificarCondicoesDeExclusaoCliente,
                                 data=[cliente['cpf'], dialogo, estruturaPagina])
        linhaBotoes = ft.Row(controls=[botaoAlterar, botaoRemover], alignment=ft.MainAxisAlignment.END)

        clienteModelo = ctCliente.criarCliente(cliente['nome'], cliente['cpf'],
                                               cliente['email'], cliente['telefone'],
                                               linhaBotoes)
        listElementosColunaCliente.append(clienteModelo)

    colunaClientes = ft.Container(content=ft.Column(controls=listElementosColunaCliente,
                                                    horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                                                    scroll=ft.ScrollMode.AUTO),
                                  expand=True,
                                  padding=20)

    return colunaClientes

def telaClientes(estruturaPagina=None, mensagem=None):
    if mensagem == None:
        mensagem = ""

    telaLadoCadastro = ladoCadastro(estruturaPagina, mensagem)
    telaLadoLista = ladoLista(estruturaPagina)

    divisoriaVertical = ft.VerticalDivider(1, color=ft.Colors.GREY)

    divisaoTela = ft.Row(controls=[telaLadoCadastro, divisoriaVertical, telaLadoLista], expand=True)
    tela = ft.Container(content=divisaoTela, expand=True)

    return tela

import flet as ft

def criarTitulo(texto):
    titulo = ft.Container(content=ft.Text(texto, size=30, weight=ft.FontWeight.BOLD, color=ft.Colors.ORANGE),
                          alignment=ft.Alignment.CENTER)
    return titulo

# O texto que fica em cima do campo é guardado no "data" do campo (ele nunca muda).
# O "data" do próprio texto guarda o valor original (usado só nas telas de alterar,
# para o código/CPF atual do item não ser tratado como repetido)
def criarCampo(rotulo, aoDigitar=None, valor="", icone=None, dica=None, valorOriginal=None):
    textoRotulo = ft.Text(rotulo, size=18, color=ft.Colors.WHITE, data=valorOriginal)
    campo = ft.TextField(value=valor,
                         data=textoRotulo,
                         prefix_icon=icone,
                         hint_text=dica,
                         border_color=ft.Colors.WHITE,
                         border_radius=10,
                         text_size=18,
                         on_change=aoDigitar)
    return campo

# Junta o texto de cima com o campo, para colocar na tela
def criarBlocoCampo(campo):
    bloco = ft.Column(controls=[campo.data, campo],
                      spacing=5,
                      horizontal_alignment=ft.CrossAxisAlignment.STRETCH)
    return bloco


# Linha com um ícone e um texto (usada dentro dos cards de cliente, prato e pedido)
def criarLinhaInfo(icone, texto, negrito=False):
    peso = ft.FontWeight.BOLD if negrito else ft.FontWeight.NORMAL
    linha = ft.Row(controls=[ft.Icon(icon=icone, size=20, color=ft.Colors.GREY),
                             ft.Text(texto, size=17, weight=peso, expand=True)],
                   spacing=10,
                   vertical_alignment=ft.CrossAxisAlignment.CENTER)
    return linha

# Círculo com um ícone dentro (no lugar da foto), usado no topo dos cards
def criarAvatar(icone):
    avatar = ft.Container(content=ft.Icon(icon=icone, size=28, color=ft.Colors.ORANGE),
                          width=48,
                          height=48,
                          bgcolor=ft.Colors.GREY_800,
                          border_radius=24,
                          alignment=ft.Alignment.CENTER)
    return avatar

# Estrutura comum dos cards: fundo cinza escuro, cantos arredondados e espaço em volta
def criarCard(listaElementos):
    card = ft.Container(content=ft.Column(controls=listaElementos, spacing=8),
                        bgcolor=ft.Colors.GREY_900,
                        border_radius=12,
                        padding=15,
                        margin=5)
    return card

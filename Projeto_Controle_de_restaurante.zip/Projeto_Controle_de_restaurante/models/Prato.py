import flet as ft
import models.bancoDados
import models.utilidades as ut
import views.menu as menu

def verificarNomeDigitado(e: ft.Event[ft.TextField]):
    ut.verificarCampo(e.control, ut.validarTexto(e.control.value))
    e.page.update()

def verificarCodigoDigitado(e: ft.Event[ft.TextField]):
    ut.verificarCampo(e.control, ut.validarCodigo(e.control.value))
    e.page.update()

def verificarCategoriaDigitada(e: ft.Event[ft.TextField]):
    ut.verificarCampo(e.control, ut.validarCategoria(e.control.value))
    e.page.update()

def verificarPrecoDigitado(e: ft.Event[ft.TextField]):
    ut.verificarCampo(e.control, ut.validarPreco(e.control.value))
    e.page.update()

def verificarTempoDigitado(e: ft.Event[ft.TextField]):
    ut.verificarCampo(e.control, ut.validarTempo(e.control.value))
    e.page.update()

def pegarListaPratos():
    return models.bancoDados.pegarListaPratos()

def pegarDadosPratoPeloCodigo(codigo):
    return models.bancoDados.pegarPratoPeloCodigo(codigo)

# Valida os 5 campos. Retorna True se tudo estiver correto
def validarCamposPrato(campoCodigo, campoNome, campoCategoria, campoPreco, campoTempo, codigoAntigo=None):
    codigoValido = ut.verificarCampo(campoCodigo, ut.validarCodigo(campoCodigo.value))
    nomeValido = ut.verificarCampo(campoNome, ut.validarTexto(campoNome.value))
    categoriaValida = ut.verificarCampo(campoCategoria, ut.validarCategoria(campoCategoria.value))
    precoValido = ut.verificarCampo(campoPreco, ut.validarPreco(campoPreco.value))
    tempoValido = ut.verificarCampo(campoTempo, ut.validarTempo(campoTempo.value))

    if codigoValido:
        codigo = campoCodigo.value.strip()
        if codigo != codigoAntigo and models.bancoDados.encontrar_prato(codigo) != None:
            codigoValido = ut.verificarCampo(campoCodigo, "Código já cadastrado")
        elif codigo != codigoAntigo and codigoAntigo != None and models.bancoDados.pratoTemPedidos(codigoAntigo):
            codigoValido = ut.verificarCampo(campoCodigo, "Prato com pedidos: código não pode mudar")

    return codigoValido and nomeValido and categoriaValida and precoValido and tempoValido

# Função do pacote
def cadastrarPrato(e: ft.Event[ft.Button]):
    campoCodigo = e.control.data[0]
    campoNome = e.control.data[1]
    campoCategoria = e.control.data[2]
    campoPreco = e.control.data[3]
    campoTempo = e.control.data[4]
    textoMensagem = e.control.data[5]
    estruturaPagina = e.control.data[6]

    tudoCorreto = validarCamposPrato(campoCodigo, campoNome, campoCategoria, campoPreco, campoTempo)

    if(tudoCorreto):
        nome = campoNome.value.strip()
        models.bancoDados.adicionarPrato(campoCodigo.value.strip(),
                                         nome,
                                         ut.acharCategoria(campoCategoria.value),
                                         ut.converterNumero(campoPreco.value),
                                         int(campoTempo.value))
        menu.ao_mudar_aba(estruturaPagina, 1, f"Prato {nome} cadastrado com sucesso")
    else:
        textoMensagem.color = ft.Colors.RED
        textoMensagem.value = "Corrija os campos destacados"

    e.page.update()

def atualizarPrato(e: ft.Event[ft.Button]):
    campoCodigo = e.control.data[0]
    campoNome = e.control.data[1]
    campoCategoria = e.control.data[2]
    campoPreco = e.control.data[3]
    campoTempo = e.control.data[4]
    codigoAntigo = e.control.data[5]
    textoMensagem = e.control.data[6]
    estruturaPagina = e.control.data[7]

    tudoCorreto = validarCamposPrato(campoCodigo, campoNome, campoCategoria, campoPreco, campoTempo, codigoAntigo)

    if(tudoCorreto):
        models.bancoDados.alterarPrato(codigoAntigo,
                                       campoCodigo.value.strip(),
                                       campoNome.value.strip(),
                                       ut.acharCategoria(campoCategoria.value),
                                       ut.converterNumero(campoPreco.value),
                                       int(campoTempo.value))
        menu.ao_mudar_aba(estruturaPagina, 1)
    else:
        textoMensagem.color = ft.Colors.RED
        textoMensagem.value = "Corrija os campos destacados"

    e.page.update()

def excluirPrato(e: ft.Event[ft.Button]):
    indiceEncontrado = e.control.data[0]
    estruturaPagina = e.control.data[1]

    models.bancoDados.removerPrato(indiceEncontrado)
    e.page.pop_dialog()

    menu.ao_mudar_aba(estruturaPagina, 1)

def verificarCondicoesDeExclusao(e: ft.Event[ft.Button]):
    codigoPrato = e.control.data[0]
    dialogo = e.control.data[1]
    estruturaPagina = e.control.data[2]

    indiceEncontrado = models.bancoDados.encontrar_prato(codigoPrato)
    if indiceEncontrado == None:
        dialogo.content.value = "Erro: Não foi possível encontrar o prato"
        dialogo.actions = [ft.Button("Fechar", on_click=ut.fecharDialogo)]
    elif models.bancoDados.pratoTemPedidos(codigoPrato):
        dialogo.content.value = "Não é possível excluir: este prato já foi pedido. Remova os pedidos primeiro."
        dialogo.actions = [ft.Button("Fechar", on_click=ut.fecharDialogo)]
    else:
        dialogo.content.value = f"Tem certeza que deseja excluir o prato com Código: {codigoPrato}"
        dialogo.actions = [ft.Button("Cancelar", on_click=ut.fecharDialogo),
                           ft.Button("Excluir", on_click=excluirPrato, data=[indiceEncontrado, estruturaPagina])]
    e.page.show_dialog(dialogo)
    e.page.update()

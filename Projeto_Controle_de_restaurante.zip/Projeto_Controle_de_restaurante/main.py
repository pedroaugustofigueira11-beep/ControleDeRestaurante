
import flet as ft
from telas.home import home
from telas.clientes import tela_clientes


def main(page: ft.Page):
    page.title = "FOOD - Painel Administrativo"
    page.bgcolor = "#111111"
    page.padding = 0
    page.spacing = 0
    page.theme_mode = ft.ThemeMode.DARK

    # Carregar tela Home
    page.add(home())
    page.add(tela_clientes())
    page.update()


if __name__ == "__main__":
    ft.run(main)

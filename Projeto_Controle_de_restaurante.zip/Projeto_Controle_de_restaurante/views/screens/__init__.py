from views.screens.clientes import telaClientes
from views.screens.alterarCliente import telaAlterarCliente
from views.screens.pratos import telaPratos
from views.screens.alterarPrato import telaAlterarPrato
from views.screens.pedidos import telaPedidos

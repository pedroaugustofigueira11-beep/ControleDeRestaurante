
import flet as ft

def tela_pedidos(page: ft.Page):
    return ft.Container(
        expand=True,
        bgcolor="#111111",
        content=ft.Row([
            ft.Container(
                width=225,
                bgcolor="#191919",
                padding=20,
                content=ft.Column([
                    ft.Row([
                        ft.Icon(ft.Icons.RESTAURANT, color="#FF9100", size=28),
                        ft.Column([
                            ft.Text("FOOD", size=19, weight="bold"),
                            ft.Text("PAINEL ADMIN", size=9, color="#FF9100")
                        ], spacing=0)
                    ]),
                    ft.Container(height=20),
                    ft.Text("MENU PRINCIPAL", size=9, color="#777777"),
                    ft.Container(
                        bgcolor="#35220F",
                        border_radius=10,
                        padding=12,
                        content=ft.Row([
                            ft.Icon(ft.Icons.RECEIPT_LONG, color="#FF9100"),
                            ft.Text("Pedidos", color="white")
                        ])
                    ),
                    ft.Container(expand=True),
                    ft.Divider(color="#303030"),
                    ft.Row([
                        ft.Icon(ft.Icons.ACCOUNT_CIRCLE, color="#FF9100", size=32),
                        ft.Column([
                            ft.Text("Administrador", size=11),
                            ft.Text("Gerenciador", size=9, color="#A7A7A7")
                        ], spacing=2)
                    ])
                ], expand=True)
            ),
            ft.Container(
                expand=True,
                padding=30,
                content=ft.Column([
                    ft.Row([
                        ft.Column([
                            ft.Text("PEDIDOS", size=25, weight="bold"),
                            ft.Text("Gerenciamento de pedidos do restaurante", size=12, color="#A7A7A7")
                        ], spacing=4),
                        ft.Container(expand=True),
                        ft.ElevatedButton(
                            "Novo pedido",
                            icon=ft.Icons.ADD,
                            bgcolor="#FF9100",
                            color="#111111"
                        )
                    ]),
                    ft.Row([
                        ft.Container(
                            expand=True,
                            bgcolor="#1D1D1D",
                            border=ft.border.all(1, "#303030"),
                            border_radius=12,
                            padding=18,
                            content=ft.Column([
                                ft.Icon(ft.Icons.RECEIPT_LONG, color="#FF9100", size=25),
                                ft.Text("Total de pedidos", size=12, color="#A7A7A7"),
                                ft.Text("156", size=27, weight="bold"),
                                ft.Text("Pedidos registrados", size=10, color="#FF9100")
                            ], spacing=8)
                        ),
                        ft.Container(
                            expand=True,
                            bgcolor="#1D1D1D",
                            border=ft.border.all(1, "#303030"),
                            border_radius=12,
                            padding=18,
                            content=ft.Column([
                                ft.Icon(ft.Icons.SCHEDULE, color="#FF9100", size=25),
                                ft.Text("Pendentes", size=12, color="#A7A7A7"),
                                ft.Text("12", size=27, weight="bold"),
                                ft.Text("Aguardando atendimento", size=10, color="#FF9100")
                            ], spacing=8)
                        ),
                        ft.Container(
                            expand=True,
                            bgcolor="#1D1D1D",
                            border=ft.border.all(1, "#303030"),
                            border_radius=12,
                            padding=18,
                            content=ft.Column([
                                ft.Icon(ft.Icons.CHECK_CIRCLE, color="#FF9100", size=25),
                                ft.Text("Concluídos", size=12, color="#A7A7A7"),
                                ft.Text("132", size=27, weight="bold"),
                                ft.Text("Pedidos finalizados", size=10, color="#FF9100")
                            ], spacing=8)
                        )
                    ], spacing=15),
                    ft.Text("Lista de pedidos", size=16, weight="bold"),
                    ft.Row([
                        ft.TextField(
                            hint_text="Pesquisar pedido ou cliente...",
                            prefix_icon=ft.Icons.SEARCH,
                            expand=True,
                            height=45,
                            bgcolor="#1D1D1D",
                            border_color="#303030",
                            focused_border_color="#FF9100",
                            border_radius=9
                        ),
                        ft.Dropdown(
                            width=155,
                            height=45,
                            value="Todos",
                            options=[
                                ft.dropdown.Option("Todos"),
                                ft.dropdown.Option("Pendente"),
                                ft.dropdown.Option("Em preparo"),
                                ft.dropdown.Option("Concluído"),
                                ft.dropdown.Option("Cancelado")
                            ],
                            bgcolor="#1D1D1D",
                            border_color="#303030",
                            focused_border_color="#FF9100"
                        )
                    ], spacing=10),
                    ft.Container(
                        expand=True,
                        bgcolor="#1D1D1D",
                        border=ft.border.all(1, "#303030"),
                        border_radius=12,
                        clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
                        content=ft.Column([
                            ft.Container(
                                bgcolor="#242424",
                                padding=15,
                                content=ft.Row([
                                    ft.Text("PEDIDO", expand=1, size=10, weight="bold", color="#A7A7A7"),
                                    ft.Text("CLIENTE", expand=2, size=10, weight="bold", color="#A7A7A7"),
                                    ft.Text("DATA", expand=1, size=10, weight="bold", color="#A7A7A7"),
                                    ft.Text("VALOR", expand=1, size=10, weight="bold", color="#A7A7A7"),
                                    ft.Text("STATUS", expand=1, size=10, weight="bold", color="#A7A7A7")
                                ])
                            ),
                            *[
                                ft.Container(
                                    padding=15,
                                    border=ft.border.only(bottom=ft.BorderSide(1, "#303030")),
                                    content=ft.Row([
                                        ft.Text(codigo, expand=1, size=11, weight="bold", color="#FF9100"),
                                        ft.Text(cliente, expand=2, size=11),
                                        ft.Text(data, expand=1, size=10, color="#A7A7A7"),
                                        ft.Text(valor, expand=1, size=11),
                                        ft.Container(
                                            expand=1,
                                            content=ft.Text(
                                                status,
                                                size=10,
                                                color=cor
                                            )
                                        )
                                    ])
                                )
                                for codigo, cliente, data, valor, status, cor in [
                                    ("#PED001", "Ana Carolina", "10/11/26", "R$ 42,90", "Concluído", "#36C98F"),
                                    ("#PED002", "Bruno Henrique", "10/11/26", "R$ 58,00", "Em preparo", "#FF9100"),
                                    ("#PED003", "Camila Oliveira", "10/11/26", "R$ 79,90", "Pendente", "#E5C45B"),
                                    ("#PED004", "Daniel Santos", "09/11/26", "R$ 35,00", "Cancelado", "#F06B6B"),
                                    ("#PED005", "Eduarda Lima", "09/11/26", "R$ 64,50", "Concluído", "#36C98F")
                                ]
                            ]
                        ], scroll=ft.ScrollMode.AUTO, spacing=0)
                    )
                ], spacing=17, expand=True)
            )
        ], spacing=0, expand=True)
    )

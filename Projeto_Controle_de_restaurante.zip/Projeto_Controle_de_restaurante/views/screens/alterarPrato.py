import flet as ft
import views.components.campo as ct
import models
import views.menu as menu

def voltarListaPratos(e: ft.Event[ft.Button]):
    estruturaPagina = e.control.data[0]
    menu.ao_mudar_aba(estruturaPagina, 1)

def telaAlterarPrato(estruturaPagina, codigoPrato):
    dadosPrato = models.pegarDadosPratoPeloCodigo(codigoPrato)

    titulo = ct.criarTitulo("Alterar Prato")

    campoCodigo = ct.criarCampo("Código do prato", models.verificarCodigoDigitado, dadosPrato["codigo"])
    campoNome = ct.criarCampo("Nome", models.verificarNomePratoDigitado, dadosPrato["nome"])
    campoCategoria = ct.criarCampo("Categoria (Entrada, Prato Principal, Sobremesa, Bebida)", models.verificarCategoriaDigitada, dadosPrato["categoria"])
    campoPreco = ct.criarCampo("Preço (ex: 25,90)", models.verificarPrecoDigitado, f"{dadosPrato['preco']:.2f}")
    campoTempo = ct.criarCampo("Tempo de preparo (minutos)", models.verificarTempoDigitado, f"{dadosPrato['tempoPreparo']}")

    textoMensagens = ft.Text("", size=18)

    botaoAlterar = ft.Button(content="Alterar", icon=ft.Icons.EDIT,
                             on_click=models.atualizarPrato,
                             data=[campoCodigo, campoNome, campoCategoria, campoPreco, campoTempo,
                                   dadosPrato["codigo"], textoMensagens, estruturaPagina])

    botaoCancelar = ft.Button(content="Cancelar", icon=ft.Icons.CANCEL,
                              on_click=voltarListaPratos,
                              data=[estruturaPagina])

    linhaBotoes = ft.Row(controls=[botaoCancelar, botaoAlterar])

    linhaBotao = ft.Row(controls=[textoMensagens, linhaBotoes], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)

    conteudo = ft.Column(controls=[titulo, campoCodigo, campoNome, campoCategoria, campoPreco, campoTempo, linhaBotao],
                         scroll=ft.ScrollMode.AUTO)

    return ft.Container(content=conteudo, expand=True, padding=20)

import flet as ft
import views.components.campo as ct
import views.components.prato as ctPrato
import models
import views.menu as menu

def abrirTelaAlterar(e: ft.Event[ft.Button]):
    codigoPrato = e.control.data[0]
    estruturaPagina = e.control.data[1]

    menu.ao_mudar_aba(estruturaPagina, 4, codigoPrato)

def ladoCadastro(estruturaPagina, mensagem):
    titulo = ct.criarTitulo("Cadastro de Prato")

    campoCodigo = ct.criarCampo("Código do prato", models.verificarCodigoDigitado,
                                icone=ft.Icons.NUMBERS, dica="1234")
    campoNome = ct.criarCampo("Nome", models.verificarNomePratoDigitado,
                              icone=ft.Icons.PERSON, dica="Maria Souza")
    campoCategoria = ct.criarCampo("Categoria (Entrada, Prato Principal, Sobremesa, Bebida)", models.verificarCategoriaDigitada,
                                   icone=ft.Icons.RESTAURANT_MENU, dica="Prato principal")
    campoPreco = ct.criarCampo("Preço (ex: 25,90)", models.verificarPrecoDigitado,
                               icone=ft.Icons.MONEY, dica="R$ 67,67")
    campoTempo = ct.criarCampo("Tempo de preparo (minutos)", models.verificarTempoDigitado,
                               icone=ft.Icons.WATCH, dica="15 min")

    textoMensagens = ft.Text(mensagem, size=18, color=ft.Colors.GREEN)

    botao = ft.Button(content=ft.Text("Cadastrar", size=22, weight=ft.FontWeight.BOLD, color=ft.Colors.BLACK), 
                      icon=ft.Icons.ADD,
                      style=ft.ButtonStyle(bgcolor=ft.Colors.ORANGE,
                                           icon_color=ft.Colors.BLACK,
                                           shape=ft.RoundedRectangleBorder(radius=10)),
                      height=50,
                      expand=True,
                      on_click=models.cadastrarPrato,
                      data=[campoCodigo, campoNome, campoCategoria, campoPreco, campoTempo, textoMensagens, estruturaPagina])

    linhaBotao = ft.Row(controls=[botao], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)
    linhaMensagens = ft.Row(controls=[textoMensagens], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)

    colunaCadastro = ft.Container(content=ft.Column(controls=[titulo, ct.criarBlocoCampo(campoCodigo), ct.criarBlocoCampo(campoNome),
                                                              ct.criarBlocoCampo(campoCategoria), ct.criarBlocoCampo(campoPreco),
                                                              ct.criarBlocoCampo(campoTempo), linhaBotao, linhaMensagens],
                                                    horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                                                    spacing=20,
                                                    scroll=ft.ScrollMode.AUTO),
                                  expand=True,
                                  padding=20)

    return colunaCadastro

def ladoLista(estruturaPagina):
    titulo = ct.criarTitulo("Pratos Cadastrados")

    dialogo = ft.AlertDialog(   modal=False,
                                title=ft.Text("Aviso Importante"),
                                content=ft.Text(""),
                                actions_alignment=ft.MainAxisAlignment.END)

    listElementosColunaPrato = [titulo]
    for prato in models.pegarListaPratos():
        botaoAlterar = ft.Button(content="Alterar", icon=ft.Icons.EDIT,
                                 on_click=abrirTelaAlterar,
                                 data=[prato['codigo'], estruturaPagina])
        botaoRemover = ft.Button(content="Remover", icon=ft.Icons.REMOVE,
                                 on_click=models.verificarCondicoesDeExclusaoPrato,
                                 data=[prato['codigo'], dialogo, estruturaPagina])
        linhaBotoes = ft.Row(controls=[botaoAlterar, botaoRemover], alignment=ft.MainAxisAlignment.END)

        pratoModelo = ctPrato.criarPrato(prato['codigo'], prato['nome'], prato['categoria'],
                                         prato['preco'], prato['tempoPreparo'],
                                         linhaBotoes)
        listElementosColunaPrato.append(pratoModelo)

    colunaPratos = ft.Container(content=ft.Column(controls=listElementosColunaPrato,
                                                  horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                                                  scroll=ft.ScrollMode.AUTO),
                                expand=True,
                                padding=20)

    return colunaPratos

def telaPratos(estruturaPagina=None, mensagem=None):
    if mensagem == None:
        mensagem = ""

    telaLadoCadastro = ladoCadastro(estruturaPagina, mensagem)
    telaLadoLista = ladoLista(estruturaPagina)

    divisoriaVertical = ft.VerticalDivider(1, color=ft.Colors.GREY)

    divisaoTela = ft.Row(controls=[telaLadoCadastro, divisoriaVertical, telaLadoLista], expand=True)
    tela = ft.Container(content=divisaoTela, expand=True)

    return tela

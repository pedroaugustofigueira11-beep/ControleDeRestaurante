import flet as ft
import models.utilidades as ut

def criarPrato(codigo, nome, categoria, preco, tempoPreparo, linhasBotao = None):
    textoNome = ft.Text(nome, size=20, weight=ft.FontWeight.BOLD)
    textoCodigo = ft.Text(f"Código: {codigo}")
    textoCategoria = ft.Text(f"Categoria: {categoria}")
    textoPreco = ft.Text(f"Preço: {ut.formatarPreco(preco)}")
    textoTempo = ft.Text(f"Tempo de preparo: {tempoPreparo} min")

    listaElementos = [textoNome, textoCodigo, textoCategoria, textoPreco, textoTempo]
    if linhasBotao != None:
        listaElementos.append(linhasBotao)

    pratoModelo = ft.Container(content=ft.Column(controls=listaElementos),
                               border=ft.Border.all(1, ft.Colors.ORANGE),
                               padding=15,
                               margin=10)

    return pratoModelo

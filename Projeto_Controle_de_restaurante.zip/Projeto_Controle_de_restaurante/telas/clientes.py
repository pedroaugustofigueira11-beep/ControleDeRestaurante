
import flet as ft

def tela_clientes():
    return ft.Container(
        expand=True,
        bgcolor="#111111",
        content=ft.Row([
            ft.Container(
                width=225,
                bgcolor="#191919",
                padding=20,
                content=ft.Column([
                    ft.Row([ft.Icon(ft.Icons.RESTAURANT, color="#FF9100", size=28), ft.Column([
                        ft.Text("FOOD", size=19, weight="bold"),
                        ft.Text("PAINEL ADMIN", size=9, color="#FF9100")
                    ], spacing=0)]),
                    ft.Container(height=20),
                    ft.Text("MENU PRINCIPAL", size=9, color="#777777"),
                    ft.Container(
                        bgcolor="#35220F",
                        border_radius=10,
                        padding=12,
                        content=ft.Row([
                            ft.Icon(ft.Icons.PEOPLE, color="#FF9100"),
                            ft.Text("Clientes", color="white")
                        ])
                    ),
                    ft.Container(expand=True),
                    ft.Divider(color="#303030"),
                    ft.Row([
                        ft.Icon(ft.Icons.ACCOUNT_CIRCLE, color="#FF9100", size=32),
                        ft.Column([
                            ft.Text("Administrador", size=11),
                            ft.Text("Gerenciador", size=9, color="#A7A7A7")
                        ], spacing=2)
                    ])
                ], expand=True)
            ),
            ft.Container(
                expand=True,
                padding=30,
                content=ft.Column([
                    ft.Row([
                        ft.Column([
                            ft.Text("CLIENTES", size=25, weight="bold"),
                            ft.Text("Gerenciamento de clientes do restaurante", size=12, color="#A7A7A7")
                        ], spacing=4),
                        ft.Container(expand=True),
                        ft.ElevatedButton(
                            "Novo cliente",
                            icon=ft.Icons.ADD,
                            bgcolor="#FF9100",
                            color="#111111"
                        )
                    ]),
                    ft.Row([
                        ft.Container(
                            expand=True,
                            bgcolor="#1D1D1D",
                            border=ft.border.all(1, "#303030"),
                            border_radius=12,
                            padding=18,
                            content=ft.Column([
                                ft.Icon(ft.Icons.GROUP, color="#FF9100", size=25),
                                ft.Text("Total de clientes", size=12, color="#A7A7A7"),
                                ft.Text("124", size=27, weight="bold"),
                                ft.Text("Clientes cadastrados", size=10, color="#FF9100")
                            ], spacing=8)
                        ),
                        ft.Container(
                            expand=True,
                            bgcolor="#1D1D1D",
                            border=ft.border.all(1, "#303030"),
                            border_radius=12,
                            padding=18,
                            content=ft.Column([
                                ft.Icon(ft.Icons.PERSON_2_ROUNDED, color="#FF9100", size=25),
                                ft.Text("Clientes ativos", size=12, color="#A7A7A7"),
                                ft.Text("98", size=27, weight="bold"),
                                ft.Text("Cadastros ativos", size=10, color="#FF9100")
                            ], spacing=8)
                        ),
                        ft.Container(
                            expand=True,
                            bgcolor="#1D1D1D",
                            border=ft.border.all(1, "#303030"),
                            border_radius=12,
                            padding=18,
                            content=ft.Column([
                                ft.Icon(ft.Icons.RECEIPT_LONG, color="#FF9100", size=25),
                                ft.Text("Pedidos realizados", size=12, color="#A7A7A7"),
                                ft.Text("356", size=27, weight="bold"),
                                ft.Text("Pedidos vinculados", size=10, color="#FF9100")
                            ], spacing=8)
                        )
                    ], spacing=15),
                    ft.Text("Lista de clientes", size=16, weight="bold"),
                    ft.Row([
                        ft.TextField(
                            hint_text="Pesquisar cliente...",
                            prefix_icon=ft.Icons.SEARCH,
                            expand=True,
                            height=45,
                            bgcolor="#1D1D1D",
                            border_color="#303030",
                            focused_border_color="#FF9100",
                            border_radius=9
                        ),
                        ft.Dropdown(
                            width=145,
                            height=45,
                            value="Todos",
                            options=[
                                ft.dropdown.Option("Todos"),
                                ft.dropdown.Option("Ativos"),
                                ft.dropdown.Option("Inativos")
                            ],
                            bgcolor="#1D1D1D",
                            border_color="#303030",
                            focused_border_color="#FF9100"
                        )
                    ], spacing=10),
                    ft.Container(
                        expand=True,
                        bgcolor="#1D1D1D",
                        border=ft.border.all(1, "#303030"),
                        border_radius=12,
                        clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
                        content=ft.Column([
                            ft.Container(
                                bgcolor="#242424",
                                padding=15,
                                content=ft.Row([
                                    ft.Text("CLIENTE", expand=3, size=10, weight="bold", color="#A7A7A7"),
                                    ft.Text("TELEFONE", expand=2, size=10, weight="bold", color="#A7A7A7"),
                                    ft.Text("PEDIDOS", expand=1, size=10, weight="bold", color="#A7A7A7"),
                                    ft.Text("STATUS", expand=1, size=10, weight="bold", color="#A7A7A7")
                                ])
                            ),
                            *[
                                ft.Container(
                                    padding=15,
                                    border=ft.border.only(bottom=ft.BorderSide(1, "#303030")),
                                    content=ft.Row([
                                        ft.Row([
                                            ft.CircleAvatar(
                                                content=ft.Text(nome[0], color="#FF9100"),
                                                bgcolor="#3A260F",
                                                radius=19
                                            ),
                                            ft.Column([
                                                ft.Text(nome, size=12, weight="bold"),
                                                ft.Text(email, size=10, color="#A7A7A7")
                                            ], spacing=3)
                                        ], expand=3, spacing=10),
                                        ft.Text(telefone, expand=2, size=11),
                                        ft.Text(str(qtd), expand=1, size=12),
                                        ft.Container(
                                            expand=1,
                                            content=ft.Text(
                                                status,
                                                size=10,
                                                color="#36C98F" if status == "Ativo" else "#A7A7A7"
                                            )
                                        )
                                    ])
                                )
                                for nome, email, telefone, qtd, status in [
                                    ("Ana Carolina", "ana@email.com", "(81) 99912-3456", 12, "Ativo"),
                                    ("Bruno Henrique", "bruno@email.com", "(81) 98876-1234", 8, "Ativo"),
                                    ("Camila Oliveira", "camila@email.com", "(81) 99771-2211", 21, "Ativo"),
                                    ("Daniel Santos", "daniel@email.com", "(81) 98123-4567", 3, "Inativo"),
                                    ("Eduarda Lima", "eduarda@email.com", "(81) 99222-7788", 16, "Ativo")
                                ]
                            ]
                        ], scroll=ft.ScrollMode.AUTO, spacing=0)
                    )
                ], spacing=17, expand=True)
            )
        ], spacing=0, expand=True)
    )

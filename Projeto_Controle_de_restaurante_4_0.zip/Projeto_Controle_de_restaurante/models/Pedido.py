import flet as ft
import models.bancoDados
import models.utilidades as ut
import views.menu as menu
import views.components.botao as ctBotao
import views.components.pedido as ctPedido

# Agrupa os códigos repetidos e busca os dados de cada prato
def juntarItens(codigosPratos):
    itens = []
    posicoes = {}
    for codigo in codigosPratos:
        prato = models.bancoDados.pegarPratoPeloCodigo(codigo)
        if prato == None:
            continue
        if codigo in posicoes:
            itens[posicoes[codigo]]["quantidade"] += 1
        else:
            posicoes[codigo] = len(itens)
            itens.append({"nome": prato["nome"],
                          "preco": prato["preco"],
                          "tempoPreparo": prato["tempoPreparo"],
                          "quantidade": 1})
    return itens

def calcularTotal(itens):
    total = 0
    for item in itens:
        total += item["preco"] * item["quantidade"]
    return total

# Os pratos são preparados ao mesmo tempo, então vale o maior tempo
def calcularTempo(itens):
    tempo = 0
    for item in itens:
        if item["tempoPreparo"] > tempo:
            tempo = item["tempoPreparo"]
    return tempo

# Junta o pedido com os dados do cliente e dos pratos (relacionamento "Pede")
def pegarListaPedidos():
    listaCompleta = []
    for pedido in models.bancoDados.pegarListaPedidos():
        cliente = models.bancoDados.pegarClientePeloCpf(pedido["cpf"])
        itens = juntarItens(pedido["itens"])
        if cliente != None and len(itens) > 0:
            listaCompleta.append({"codigo": pedido["codigo"],
                                  "nomeCliente": cliente["nome"],
                                  "cpf": cliente["cpf"],
                                  "itens": itens,
                                  "total": calcularTotal(itens),
                                  "tempoPreparo": calcularTempo(itens)})
    return listaCompleta

# Volta o campo ao visual normal (sem erro e sem "check")
def limparCampo(campo):
    campo.value = ""
    campo.border_color = ft.Colors.WHITE
    campo.suffix_icon = None
    campo.label = None

# Redesenha a lista de pratos do carrinho e o total (quem chama deve dar page.update)
def atualizarCarrinho(carrinho, colunaCarrinho, textoTotal):
    colunaCarrinho.controls.clear()
    total = 0

    if len(carrinho) == 0:
        colunaCarrinho.controls.append(ft.Text("Nenhum prato adicionado ainda", italic=True))

    posicao = 0
    for codigo in carrinho:
        prato = models.bancoDados.pegarPratoPeloCodigo(codigo)
        if prato != None:
            total += prato["preco"]
            botaoRemover = ft.IconButton(icon=ft.Icons.DELETE,
                                         icon_color=ft.Colors.RED,
                                         on_click=removerPratoDoCarrinho,
                                         data=[posicao, carrinho, colunaCarrinho, textoTotal])
            colunaCarrinho.controls.append(ctPedido.criarItemCarrinho(prato["nome"], prato["preco"],
                                                                      prato["tempoPreparo"], botaoRemover))
        posicao += 1

    textoTotal.value = f"Total: {ut.formatarPreco(total)}"

# Função do pacote
def adicionarPratoAoCarrinho(e: ft.Event[ft.Button]):
    campoCodigo = e.control.data[0]
    carrinho = e.control.data[1]
    colunaCarrinho = e.control.data[2]
    textoTotal = e.control.data[3]
    textoMensagem = e.control.data[4]

    codigoValido = ut.verificarCampo(campoCodigo, ut.validarCodigo(campoCodigo.value))

    prato = None
    if codigoValido:
        prato = models.bancoDados.pegarPratoPeloCodigo(campoCodigo.value.strip())
        if prato == None:
            codigoValido = ut.verificarCampo(campoCodigo, "Prato não encontrado")

    if codigoValido:
        carrinho.append(prato["codigo"])
        limparCampo(campoCodigo)
        textoMensagem.value = ""
        atualizarCarrinho(carrinho, colunaCarrinho, textoTotal)

    e.page.update()

# Função do pacote
def removerPratoDoCarrinho(e: ft.Event[ft.IconButton]):
    posicao = e.control.data[0]
    carrinho = e.control.data[1]
    colunaCarrinho = e.control.data[2]
    textoTotal = e.control.data[3]

    if posicao < len(carrinho):
        carrinho.pop(posicao)
    atualizarCarrinho(carrinho, colunaCarrinho, textoTotal)
    e.page.update()

# Função do pacote
def cadastrarPedido(e: ft.Event[ft.Button]):
    campoCpf = e.control.data[0]
    campoCodigo = e.control.data[1]
    carrinho = e.control.data[2]
    textoMensagem = e.control.data[3]
    estruturaPagina = e.control.data[4]

    cpfValido = ut.verificarCampo(campoCpf, ut.validarCpf(campoCpf.value))

    cliente = None
    if cpfValido:
        cliente = models.bancoDados.pegarClientePeloCpf(ut.somenteDigitos(campoCpf.value))
        if cliente == None:
            cpfValido = ut.verificarCampo(campoCpf, "Cliente não encontrado")

    carrinhoValido = len(carrinho) > 0
    if not carrinhoValido:
        ut.verificarCampo(campoCodigo, "Adicione pelo menos um prato")

    if cpfValido and carrinhoValido:
        itens = juntarItens(carrinho)
        quantidade = len(carrinho)
        total = calcularTotal(itens)
        codigoPedido = models.bancoDados.adicionarPedido(cliente["cpf"], carrinho)
        menu.ao_mudar_aba(estruturaPagina, 2,
                          f"Pedido nº {codigoPedido} registrado: {cliente['nome']} pediu {quantidade} item(ns), total {ut.formatarPreco(total)}")
    else:
        textoMensagem.color = ft.Colors.RED
        textoMensagem.value = "Corrija os campos destacados"

    e.page.update()

def excluirPedido(e: ft.Event[ft.Button]):
    indiceEncontrado = e.control.data[0]
    estruturaPagina = e.control.data[1]

    models.bancoDados.removerPedido(indiceEncontrado)
    e.page.pop_dialog()

    menu.ao_mudar_aba(estruturaPagina, 2)

def verificarCondicoesDeExclusao(e: ft.Event[ft.Button]):
    codigoPedido = e.control.data[0]
    dialogo = e.control.data[1]
    estruturaPagina = e.control.data[2]

    indiceEncontrado = models.bancoDados.encontrar_pedido(codigoPedido)
    if indiceEncontrado == None:
        dialogo.content.value = "Erro: Não foi possível encontrar o pedido"
        dialogo.actions = [ft.Button("Fechar", on_click=ut.fecharDialogo)]
    else:
        dialogo.content.value = f"Tem certeza que deseja excluir o pedido número: {codigoPedido}"
        dialogo.actions = [ft.Button("Cancelar", on_click=ut.fecharDialogo),
                           ctBotao.criarBotao("Excluir", ft.Icons.DELETE, ft.Colors.RED_700, excluirPedido, [indiceEncontrado, estruturaPagina])]
    e.page.show_dialog(dialogo)
    e.page.update()
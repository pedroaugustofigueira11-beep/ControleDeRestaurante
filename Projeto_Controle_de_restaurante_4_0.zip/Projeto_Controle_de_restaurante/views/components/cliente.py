import flet as ft
import models.utilidades as ut
import views.components.campo as ct

def criarCliente(nome, cpf, email, telefone, linhasBotao = None):
    topo = ft.Row(controls=[ct.criarAvatar(ft.Icons.PERSON),
                            ft.Text(nome, size=22, weight=ft.FontWeight.BOLD, expand=True)],
                  spacing=15,
                  vertical_alignment=ft.CrossAxisAlignment.CENTER)

    listaElementos = [topo,
                      ct.criarLinhaInfo(ft.Icons.BADGE, f"CPF: {ut.formatarCpf(cpf)}"),
                      ct.criarLinhaInfo(ft.Icons.EMAIL, email),
                      ct.criarLinhaInfo(ft.Icons.PHONE, ut.formatarTelefone(telefone))]
    if linhasBotao != None:
        listaElementos.append(linhasBotao)

    return ct.criarCard(listaElementos)

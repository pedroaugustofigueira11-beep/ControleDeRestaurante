import flet as ft
import models.bancoDados
import models.utilidades as ut
import views.menu as menu
import views.components.botao as ctBotao

def verificarNomeDigitado(e: ft.Event[ft.TextField]):
    ut.verificarCampo(e.control, ut.validarTexto(e.control.value))
    e.page.update()

# Usada na aba Pedidos (só confere o formato do CPF)
def verificarCpfDigitado(e: ft.Event[ft.TextField]):
    ut.verificarCampo(e.control, ut.validarCpf(e.control.value))
    e.page.update()

# Confere o CPF do cliente: formato, CPF repetido e cliente com pedidos.
# cpfAntigo é None no cadastro e o CPF atual do cliente na tela de alterar
def validarCpfCliente(valor, cpfAntigo=None):
    erro = ut.validarCpf(valor)
    if erro != "":
        return erro

    cpf = ut.somenteDigitos(valor)
    if cpf != cpfAntigo:
        if models.bancoDados.encontrar_cliente(cpf) != None:
            return "CPF já cadastrado"
        if cpfAntigo != None and models.bancoDados.clienteTemPedidos(cpfAntigo):
            return "Cliente com pedidos: CPF não pode mudar"
    return ""

# Usada nas telas de cadastro e alterar cliente (verifica enquanto digita)
def verificarCpfClienteDigitado(e: ft.Event[ft.TextField]):
    cpfAntigo = e.control.data.data
    ut.verificarCampo(e.control, validarCpfCliente(e.control.value, cpfAntigo))
    e.page.update()

def verificarEmailDigitado(e: ft.Event[ft.TextField]):
    ut.verificarCampo(e.control, ut.validarEmail(e.control.value))
    e.page.update()

def verificarTelefoneDigitado(e: ft.Event[ft.TextField]):
    ut.verificarCampo(e.control, ut.validarTelefone(e.control.value))
    e.page.update()

def pegarListaClientes():
    return models.bancoDados.pegarListaClientes()

def pegarDadosClientePeloCpf(cpf):
    return models.bancoDados.pegarClientePeloCpf(cpf)

# Valida os 4 campos. Retorna True se tudo estiver correto
def validarCamposCliente(campoNome, campoCpf, campoEmail, campoTelefone, cpfAntigo=None):
    nomeValido = ut.verificarCampo(campoNome, ut.validarTexto(campoNome.value))
    cpfValido = ut.verificarCampo(campoCpf, validarCpfCliente(campoCpf.value, cpfAntigo))
    emailValido = ut.verificarCampo(campoEmail, ut.validarEmail(campoEmail.value))
    telefoneValido = ut.verificarCampo(campoTelefone, ut.validarTelefone(campoTelefone.value))

    return nomeValido and cpfValido and emailValido and telefoneValido

# Função do pacote
def cadastrarCliente(e: ft.Event[ft.Button]):
    campoNome = e.control.data[0]
    campoCpf = e.control.data[1]
    campoEmail = e.control.data[2]
    campoTelefone = e.control.data[3]
    textoMensagem = e.control.data[4]
    estruturaPagina = e.control.data[5]

    tudoCorreto = validarCamposCliente(campoNome, campoCpf, campoEmail, campoTelefone)

    if(tudoCorreto):
        nome = campoNome.value.strip()
        models.bancoDados.adicionarCliente(nome,
                                           ut.somenteDigitos(campoCpf.value),
                                           campoEmail.value.strip(),
                                           ut.somenteDigitos(campoTelefone.value))
        menu.ao_mudar_aba(estruturaPagina, 0, f"Cliente {nome} cadastrado com sucesso")
    else:
        textoMensagem.color = ft.Colors.RED
        textoMensagem.value = "Corrija os campos destacados"

    e.page.update()

def atualizarCliente(e: ft.Event[ft.Button]):
    campoNome = e.control.data[0]
    campoCpf = e.control.data[1]
    campoEmail = e.control.data[2]
    campoTelefone = e.control.data[3]
    cpfAntigo = e.control.data[4]
    textoMensagem = e.control.data[5]
    estruturaPagina = e.control.data[6]

    tudoCorreto = validarCamposCliente(campoNome, campoCpf, campoEmail, campoTelefone, cpfAntigo)

    if(tudoCorreto):
        models.bancoDados.alterarCliente(cpfAntigo,
                                         campoNome.value.strip(),
                                         ut.somenteDigitos(campoCpf.value),
                                         campoEmail.value.strip(),
                                         ut.somenteDigitos(campoTelefone.value))
        menu.ao_mudar_aba(estruturaPagina, 0)
    else:
        textoMensagem.color = ft.Colors.RED
        textoMensagem.value = "Corrija os campos destacados"

    e.page.update()

def excluirCliente(e: ft.Event[ft.Button]):
    indiceEncontrado = e.control.data[0]
    estruturaPagina = e.control.data[1]

    models.bancoDados.removerCliente(indiceEncontrado)
    e.page.pop_dialog()

    menu.ao_mudar_aba(estruturaPagina, 0)

def verificarCondicoesDeExclusao(e: ft.Event[ft.Button]):
    cpfCliente = e.control.data[0]
    dialogo = e.control.data[1]
    estruturaPagina = e.control.data[2]

    indiceEncontrado = models.bancoDados.encontrar_cliente(cpfCliente)
    if indiceEncontrado == None:
        dialogo.content.value = "Erro: Não foi possível encontrar o cliente"
        dialogo.actions = [ft.Button("Fechar", on_click=ut.fecharDialogo)]
    elif models.bancoDados.clienteTemPedidos(cpfCliente):
        dialogo.content.value = "Não é possível excluir: este cliente possui pedidos registrados. Remova os pedidos primeiro."
        dialogo.actions = [ft.Button("Fechar", on_click=ut.fecharDialogo)]
    else:
        dialogo.content.value = f"Tem certeza que deseja excluir o cliente com CPF: {ut.formatarCpf(cpfCliente)}"
        dialogo.actions = [ft.Button("Cancelar", on_click=ut.fecharDialogo),
                           ctBotao.criarBotao("Excluir", ft.Icons.DELETE, ft.Colors.RED_700, excluirCliente, [indiceEncontrado, estruturaPagina])]
    e.page.show_dialog(dialogo)
    e.page.update()

import flet as ft
import views.components.campo as ct
import views.components.cliente as ctCliente
import views.components.botao as ctBotao
import models
import views.menu as menu

def abrirTelaAlterar(e: ft.Event[ft.Button]):
    cpfCliente = e.control.data[0]
    estruturaPagina = e.control.data[1]

    menu.ao_mudar_aba(estruturaPagina, 3, cpfCliente)

def ladoCadastro(estruturaPagina, mensagem):
    titulo = ct.criarTitulo("Cadastro de Cliente")

    campoNome = ct.criarCampo("Nome Completo", models.verificarNomeClienteDigitado,
                              icone=ft.Icons.PERSON, dica="Maria Souza")
    campoCpf = ct.criarCampo("CPF", models.verificarCpfClienteDigitado,
                             icone=ft.Icons.BADGE, dica="000.000.000-00")
    campoEmail = ct.criarCampo("E-mail", models.verificarEmailDigitado,
                               icone=ft.Icons.EMAIL, dica="exemplo@email.com")
    campoTelefone = ct.criarCampo("Telefone com DDD", models.verificarTelefoneDigitado,
                                  icone=ft.Icons.PHONE, dica="(00) 00000-0000")

    textoMensagens = ft.Text(mensagem, size=18, color=ft.Colors.GREEN)

    botao = ft.Button(content=ft.Text("Cadastrar", size=22, weight=ft.FontWeight.BOLD, color=ft.Colors.BLACK),
                      icon=ft.Icons.ADD,
                      style=ft.ButtonStyle(bgcolor=ft.Colors.ORANGE,
                                           icon_color=ft.Colors.BLACK,
                                           shape=ft.RoundedRectangleBorder(radius=10)),
                      height=50,
                      expand=True,
                      on_click=models.cadastrarCliente,
                      data=[campoNome, campoCpf, campoEmail, campoTelefone, textoMensagens, estruturaPagina])

    linhaBotao = ft.Row(controls=[botao])
    linhaMensagem = ft.Row(controls=[textoMensagens])

    colunaCadastro = ft.Container(content=ft.Column(controls=[titulo,
                                                              ct.criarBlocoCampo(campoNome),
                                                              ct.criarBlocoCampo(campoCpf),
                                                              ct.criarBlocoCampo(campoEmail),
                                                              ct.criarBlocoCampo(campoTelefone),
                                                              linhaBotao,
                                                              linhaMensagem],
                                                    alignment=ft.MainAxisAlignment.START,
                                                    horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                                                    spacing=20,
                                                    scroll=ft.ScrollMode.AUTO),
                                  expand=True,
                                  padding=20)

    return colunaCadastro

def ladoLista(estruturaPagina):
    titulo = ct.criarTitulo("Clientes Cadastrados")

    dialogo = ft.AlertDialog(   modal=False,
                                title=ft.Text("Aviso Importante"),
                                content=ft.Text(""),
                                actions_alignment=ft.MainAxisAlignment.END)

    listElementosColunaCliente = [titulo]
    for cliente in models.pegarListaClientes():
        botaoAlterar = ctBotao.criarBotaoAlterar(abrirTelaAlterar,
                                                 [cliente['cpf'], estruturaPagina])
        botaoRemover = ctBotao.criarBotaoRemover(models.verificarCondicoesDeExclusaoCliente,
                                                 [cliente['cpf'], dialogo, estruturaPagina])
        linhaBotoes = ft.Row(controls=[botaoAlterar, botaoRemover], alignment=ft.MainAxisAlignment.END)

        clienteModelo = ctCliente.criarCliente(cliente['nome'], cliente['cpf'],
                                               cliente['email'], cliente['telefone'],
                                               linhaBotoes)
        listElementosColunaCliente.append(clienteModelo)

    colunaClientes = ft.Container(content=ft.Column(controls=listElementosColunaCliente,
                                                    horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                                                    scroll=ft.ScrollMode.AUTO),
                                  expand=True,
                                  padding=20)

    return colunaClientes

def telaClientes(estruturaPagina=None, mensagem=None):
    if mensagem == None:
        mensagem = ""

    telaLadoCadastro = ladoCadastro(estruturaPagina, mensagem)
    telaLadoLista = ladoLista(estruturaPagina)

    divisoriaVertical = ft.VerticalDivider(1, color=ft.Colors.GREY)

    divisaoTela = ft.Row(controls=[telaLadoCadastro, divisoriaVertical, telaLadoLista], expand=True)
    tela = ft.Container(content=divisaoTela, expand=True)

    return tela

# Relacionamento "Pede": um cliente (cpf) pede vários pratos (codigoPrato)
listaPedidos = [
{
    "codigo": 1,
    "cpf": "12345678909",
    "codigoPrato": "1",
},
{
    "codigo": 2,
    "cpf": "12345678909",
    "codigoPrato": "2",
},
{
    "codigo": 3,
    "cpf": "98765432100",
    "codigoPrato": "3",
},
]

def encontrar_pedido(codigo):
    indice = 0
    for item in listaPedidos:
        if item["codigo"] == codigo:
            return indice
        indice += 1

    return None

def pegarListaPedidos():
    return listaPedidos

def gerarCodigoPedido():
    maior = 0
    for item in listaPedidos:
        if item["codigo"] > maior:
            maior = item["codigo"]
    return maior + 1

def adicionarPedido(cpf, codigoPrato):
    pedido = {"codigo": gerarCodigoPedido(),
              "cpf": cpf,
              "codigoPrato": codigoPrato
              }
    listaPedidos.append(pedido)

def removerPedido(indiceExcluir):
    listaPedidos.pop(indiceExcluir)

def clienteTemPedidos(cpf):
    for item in listaPedidos:
        if item["cpf"] == cpf:
            return True

    return False

def pratoTemPedidos(codigoPrato):
    for item in listaPedidos:
        if item["codigoPrato"] == codigoPrato:
            return True

    return False

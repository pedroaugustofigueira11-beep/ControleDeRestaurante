import flet as ft
import views.components.campo as ct
import views.components.pedido as ctPedido
import views.components.botao as ctBotao
import models

def ladoCadastro(estruturaPagina, mensagem):
    titulo = ct.criarTitulo("Novo Pedido")

    dica = ft.Text("Use o CPF da aba Clientes e o código da aba Pratos. Adicione quantos pratos quiser antes de registrar.")

    campoCpf = ct.criarCampo("CPF do cliente", models.verificarCpfDigitado,
                             icone=ft.Icons.BADGE, dica="000.000.000-00")
    campoCodigo = ct.criarCampo("Código do prato", models.verificarCodigoDigitado,
                                icone=ft.Icons.NUMBERS, dica="1234")

    textoMensagens = ft.Text(mensagem, size=18, color=ft.Colors.GREEN)

    # Carrinho: lista de códigos de prato do pedido que está sendo montado
    carrinho = []
    colunaCarrinho = ft.Column(controls=[], spacing=8)
    textoTotal = ft.Text("", size=20, weight=ft.FontWeight.BOLD, color=ft.Colors.ORANGE)
    models.atualizarCarrinho(carrinho, colunaCarrinho, textoTotal)

    tituloCarrinho = ft.Text("Pratos do pedido", size=22, weight=ft.FontWeight.BOLD)

    botaoAdicionar = ft.Button(content=ft.Text("Adicionar prato", size=20, weight=ft.FontWeight.BOLD, color=ft.Colors.ORANGE),
                               icon=ft.Icons.ADD_SHOPPING_CART,
                               style=ft.ButtonStyle(bgcolor=ft.Colors.TRANSPARENT,
                                                    icon_color=ft.Colors.ORANGE,
                                                    side=ft.BorderSide(2, ft.Colors.ORANGE),
                                                    shape=ft.RoundedRectangleBorder(radius=10)),
                               height=45,
                               expand=True,
                               on_click=models.adicionarPratoAoCarrinho,
                               data=[campoCodigo, carrinho, colunaCarrinho, textoTotal, textoMensagens])

    botao = ft.Button(content=ft.Text("Registrar Pedido", size=22, weight=ft.FontWeight.BOLD, color=ft.Colors.BLACK),
                      icon=ft.Icons.CHECK,
                      style=ft.ButtonStyle(bgcolor=ft.Colors.ORANGE,
                                           icon_color=ft.Colors.BLACK,
                                           shape=ft.RoundedRectangleBorder(radius=10)),
                      height=50,
                      expand=True,
                      on_click=models.cadastrarPedido,
                      data=[campoCpf, campoCodigo, carrinho, textoMensagens, estruturaPagina])

    linhaAdicionar = ft.Row(controls=[botaoAdicionar], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)
    linhaBotao = ft.Row(controls=[botao], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)
    linhaMensagem = ft.Row(controls=[textoMensagens], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)

    colunaCadastro = ft.Container(content=ft.Column(controls=[titulo, dica,
                                                              ct.criarBlocoCampo(campoCpf),
                                                              ct.criarBlocoCampo(campoCodigo),
                                                              linhaAdicionar,
                                                              tituloCarrinho, colunaCarrinho, textoTotal,
                                                              linhaBotao, linhaMensagem],
                                                    horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                                                    spacing=20,
                                                    scroll=ft.ScrollMode.AUTO),
                                  expand=True,
                                  padding=20)

    return colunaCadastro

def ladoLista(estruturaPagina):
    titulo = ct.criarTitulo("Pedidos Registrados")

    dialogo = ft.AlertDialog(   modal=False,
                                title=ft.Text("Aviso Importante"),
                                content=ft.Text(""),
                                actions_alignment=ft.MainAxisAlignment.END)

    listElementosColunaPedido = [titulo]
    for pedido in models.pegarListaPedidos():
        botaoRemover = ctBotao.criarBotaoRemover(models.verificarCondicoesDeExclusaoPedido,
                                                 [pedido['codigo'], dialogo, estruturaPagina])
        linhaBotoes = ft.Row(controls=[botaoRemover], alignment=ft.MainAxisAlignment.END)

        pedidoModelo = ctPedido.criarPedido(pedido['codigo'], pedido['nomeCliente'], pedido['cpf'],
                                            pedido['itens'], pedido['total'], pedido['tempoPreparo'],
                                            linhaBotoes)
        listElementosColunaPedido.append(pedidoModelo)

    colunaPedidos = ft.Container(content=ft.Column(controls=listElementosColunaPedido,
                                                   horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                                                   scroll=ft.ScrollMode.AUTO),
                                 expand=True,
                                 padding=20)

    return colunaPedidos

def telaPedidos(estruturaPagina=None, mensagem=None):
    if mensagem == None:
        mensagem = ""

    telaLadoCadastro = ladoCadastro(estruturaPagina, mensagem)
    telaLadoLista = ladoLista(estruturaPagina)

    divisoriaVertical = ft.VerticalDivider(1, color=ft.Colors.GREY)

    divisaoTela = ft.Row(controls=[telaLadoCadastro, divisoriaVertical, telaLadoLista], expand=True)
    tela = ft.Container(content=divisaoTela, expand=True)

    return tela
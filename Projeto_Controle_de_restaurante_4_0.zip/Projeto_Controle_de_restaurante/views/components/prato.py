import flet as ft
import models.utilidades as ut
import views.components.campo as ct

# Cada categoria tem o seu ícone
ICONES_CATEGORIA = {"Entrada": ft.Icons.LUNCH_DINING,
                    "Prato Principal": ft.Icons.RESTAURANT,
                    "Sobremesa": ft.Icons.ICECREAM,
                    "Bebida": ft.Icons.LOCAL_DRINK}

def criarPrato(codigo, nome, categoria, preco, tempoPreparo, linhasBotao = None):
    icone = ICONES_CATEGORIA.get(categoria, ft.Icons.RESTAURANT_MENU)

    topo = ft.Row(controls=[ct.criarAvatar(icone),
                            ft.Text(nome, size=22, weight=ft.FontWeight.BOLD, expand=True)],
                  spacing=15,
                  vertical_alignment=ft.CrossAxisAlignment.CENTER)

    listaElementos = [topo,
                      ct.criarLinhaInfo(ft.Icons.NUMBERS, f"Código: {codigo}"),
                      ct.criarLinhaInfo(ft.Icons.CATEGORY, categoria),
                      ct.criarLinhaInfo(ft.Icons.PAYMENTS, ut.formatarPreco(preco)),
                      ct.criarLinhaInfo(ft.Icons.SCHEDULE, f"{tempoPreparo} min")]
    if linhasBotao != None:
        listaElementos.append(linhasBotao)

    return ct.criarCard(listaElementos)

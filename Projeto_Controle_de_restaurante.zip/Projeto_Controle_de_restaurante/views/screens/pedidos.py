import flet as ft
import views.components.campo as ct
import views.components.pedido as ctPedido
import models

def ladoCadastro(estruturaPagina, mensagem):
    titulo = ct.criarTitulo("Novo Pedido")

    dica = ft.Text("Use o CPF da aba Clientes e o código da aba Pratos")

    campoCpf = ct.criarCampo("CPF do cliente", models.verificarCpfDigitado,
                             icone=ft.Icons.BADGE, dica="000.000.000-00")
    campoCodigo = ct.criarCampo("Código do prato", models.verificarCodigoDigitado,
                                icone=ft.Icons.NUMBERS, dica="1234")

    textoMensagens = ft.Text(mensagem, size=18, color=ft.Colors.GREEN)

    botao = ft.Button(content=ft.Text("Registrar Pedido", size=22, weight=ft.FontWeight.BOLD, color=ft.Colors.BLACK), 
                      icon=ft.Icons.ADD,
                      style=ft.ButtonStyle(bgcolor=ft.Colors.ORANGE,
                                           icon_color=ft.Colors.BLACK,
                                           shape=ft.RoundedRectangleBorder(radius=10)),
                      height=50,
                      expand=True,
                      on_click=models.cadastrarPedido,
                      data=[campoCpf, campoCodigo, textoMensagens, estruturaPagina])

    linhaBotao = ft.Row(controls=[botao], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)
    linhaMensagem = ft.Row(controls=[textoMensagens], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)

    colunaCadastro = ft.Container(content=ft.Column(controls=[titulo, dica, ct.criarBlocoCampo(campoCpf), ct.criarBlocoCampo(campoCodigo), linhaBotao, linhaMensagem],
                                                    horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                                                    spacing=20,
                                                    scroll=ft.ScrollMode.AUTO),
                                  expand=True,
                                  padding=20)

    return colunaCadastro

def ladoLista(estruturaPagina):
    titulo = ct.criarTitulo("Pedidos Registrados")

    dialogo = ft.AlertDialog(   modal=False,
                                title=ft.Text("Aviso Importante"),
                                content=ft.Text(""),
                                actions_alignment=ft.MainAxisAlignment.END)

    listElementosColunaPedido = [titulo]
    for pedido in models.pegarListaPedidos():
        botaoRemover = ft.Button(content="Remover", icon=ft.Icons.REMOVE,
                                 on_click=models.verificarCondicoesDeExclusaoPedido,
                                 data=[pedido['codigo'], dialogo, estruturaPagina])
        linhaBotoes = ft.Row(controls=[botaoRemover], alignment=ft.MainAxisAlignment.END)

        pedidoModelo = ctPedido.criarPedido(pedido['codigo'], pedido['nomeCliente'], pedido['cpf'],
                                            pedido['nomePrato'], pedido['preco'], pedido['tempoPreparo'],
                                            linhaBotoes)
        listElementosColunaPedido.append(pedidoModelo)

    colunaPedidos = ft.Container(content=ft.Column(controls=listElementosColunaPedido,
                                                   horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                                                   scroll=ft.ScrollMode.AUTO),
                                 expand=True,
                                 padding=20)

    return colunaPedidos

def telaPedidos(estruturaPagina=None, mensagem=None):
    if mensagem == None:
        mensagem = ""

    telaLadoCadastro = ladoCadastro(estruturaPagina, mensagem)
    telaLadoLista = ladoLista(estruturaPagina)

    divisoriaVertical = ft.VerticalDivider(1, color=ft.Colors.GREY)

    divisaoTela = ft.Row(controls=[telaLadoCadastro, divisoriaVertical, telaLadoLista], expand=True)
    tela = ft.Container(content=divisaoTela, expand=True)

    return tela

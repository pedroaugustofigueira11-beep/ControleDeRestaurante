from models.bancoDados.clienteBD import adicionarCliente, alterarCliente, removerCliente, pegarListaClientes, encontrar_cliente, pegarClientePeloCpf
from models.bancoDados.pratoBD import adicionarPrato, alterarPrato, removerPrato, pegarListaPratos, encontrar_prato, pegarPratoPeloCodigo
from models.bancoDados.pedidoBD import adicionarPedido, removerPedido, pegarListaPedidos, encontrar_pedido, clienteTemPedidos, pratoTemPedidos

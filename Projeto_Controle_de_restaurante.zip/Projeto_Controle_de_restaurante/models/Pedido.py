import flet as ft
import models.bancoDados
import models.utilidades as ut
import views.menu as menu

# Junta o pedido com os dados do cliente e do prato (relacionamento "Pede")
def pegarListaPedidos():
    listaCompleta = []
    for pedido in models.bancoDados.pegarListaPedidos():
        cliente = models.bancoDados.pegarClientePeloCpf(pedido["cpf"])
        prato = models.bancoDados.pegarPratoPeloCodigo(pedido["codigoPrato"])
        if cliente != None and prato != None:
            listaCompleta.append({"codigo": pedido["codigo"],
                                  "nomeCliente": cliente["nome"],
                                  "cpf": cliente["cpf"],
                                  "nomePrato": prato["nome"],
                                  "preco": prato["preco"],
                                  "tempoPreparo": prato["tempoPreparo"]})
    return listaCompleta

# Função do pacote
def cadastrarPedido(e: ft.Event[ft.Button]):
    campoCpf = e.control.data[0]
    campoCodigo = e.control.data[1]
    textoMensagem = e.control.data[2]
    estruturaPagina = e.control.data[3]

    cpfValido = ut.verificarCampo(campoCpf, ut.validarCpf(campoCpf.value))
    codigoValido = ut.verificarCampo(campoCodigo, ut.validarCodigo(campoCodigo.value))

    cliente = None
    prato = None

    if cpfValido:
        cliente = models.bancoDados.pegarClientePeloCpf(ut.somenteDigitos(campoCpf.value))
        if cliente == None:
            cpfValido = ut.verificarCampo(campoCpf, "Cliente não encontrado")

    if codigoValido:
        prato = models.bancoDados.pegarPratoPeloCodigo(campoCodigo.value.strip())
        if prato == None:
            codigoValido = ut.verificarCampo(campoCodigo, "Prato não encontrado")

    if(cpfValido and codigoValido):
        models.bancoDados.adicionarPedido(cliente["cpf"], prato["codigo"])
        menu.ao_mudar_aba(estruturaPagina, 2, f"Pedido registrado: {cliente['nome']} pediu {prato['nome']}")
    else:
        textoMensagem.color = ft.Colors.RED
        textoMensagem.value = "Corrija os campos destacados"

    e.page.update()

def excluirPedido(e: ft.Event[ft.Button]):
    indiceEncontrado = e.control.data[0]
    estruturaPagina = e.control.data[1]

    models.bancoDados.removerPedido(indiceEncontrado)
    e.page.pop_dialog()

    menu.ao_mudar_aba(estruturaPagina, 2)

def verificarCondicoesDeExclusao(e: ft.Event[ft.Button]):
    codigoPedido = e.control.data[0]
    dialogo = e.control.data[1]
    estruturaPagina = e.control.data[2]

    indiceEncontrado = models.bancoDados.encontrar_pedido(codigoPedido)
    if indiceEncontrado == None:
        dialogo.content.value = "Erro: Não foi possível encontrar o pedido"
        dialogo.actions = [ft.Button("Fechar", on_click=ut.fecharDialogo)]
    else:
        dialogo.content.value = f"Tem certeza que deseja excluir o pedido número: {codigoPedido}"
        dialogo.actions = [ft.Button("Cancelar", on_click=ut.fecharDialogo),
                           ft.Button("Excluir", on_click=excluirPedido, data=[indiceEncontrado, estruturaPagina])]
    e.page.show_dialog(dialogo)
    e.page.update()

import flet as ft
import views.components.campo as ct
import views.components.cliente as ctCliente
import models
import views.menu as menu

def abrirTelaAlterar(e: ft.Event[ft.Button]):
    cpfCliente = e.control.data[0]
    estruturaPagina = e.control.data[1]

    menu.ao_mudar_aba(estruturaPagina, 3, cpfCliente)

def ladoCadastro(estruturaPagina, mensagem):
    titulo = ct.criarTitulo("Cadastro de Cliente")

    campoNome = ct.criarCampo("Nome", models.verificarNomeClienteDigitado,
                              icone=ft.Icons.PERSON, dica="Maria Souza")
    campoCpf = ct.criarCampo("CPF (somente números)", models.verificarCpfDigitado,
                             icone=ft.Icons.BADGE, dica="000.000.000-00")
    campoEmail = ct.criarCampo("E-mail", models.verificarEmailDigitado,
                               icone=ft.Icons.EMAIL, dica="exemplo@email.com")
    campoTelefone = ct.criarCampo("Telefone com DDD", models.verificarTelefoneDigitado,
                                  icone=ft.Icons.PHONE, dica="(00) 00000-0000")

    textoMensagens = ft.Text(mensagem, size=18, color=ft.Colors.GREEN)

    botao = ft.Button(content=ft.Text("Cadastrar Cliente", size=22, weight=ft.FontWeight.BOLD, color=ft.Colors.BLACK),
                      icon=ft.Icons.ADD,
                      style=ft.ButtonStyle(bgcolor=ft.Colors.ORANGE, color=ft.Colors.BLACK),
                      height=55,
                      expand=True,
                      on_click=models.cadastrarCliente,
                      data=[campoNome, campoCpf, campoEmail, campoTelefone, textoMensagens, estruturaPagina])

    linhaBotao = ft.Row(controls=[botao])

    colunaCadastro = ft.Container(content=ft.Column(controls=[titulo,
                                                              ct.criarBlocoCampo(campoNome),
                                                              ct.criarBlocoCampo(campoCpf),
                                                              ct.criarBlocoCampo(campoEmail),
                                                              ct.criarBlocoCampo(campoTelefone),
                                                              textoMensagens,
                                                              linhaBotao],
                                                              alignment=ft.MainAxisAlignment.START,
                                                              horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                                                              spacing=20,
                                                    scroll=ft.ScrollMode.AUTO),
                                  expand=True,
                                  padding=20)

    return colunaCadastro

def ladoLista(estruturaPagina):
    titulo = ct.criarTitulo("Clientes Cadastrados")

    dialogo = ft.AlertDialog(   modal=False,
                                title=ft.Text("Aviso Importante"),
                                content=ft.Text(""),
                                actions_alignment=ft.MainAxisAlignment.END)

    listElementosColunaCliente = [titulo]
    for cliente in models.pegarListaClientes():
        botaoAlterar = ft.Button(content="Alterar", icon=ft.Icons.EDIT,
                                 on_click=abrirTelaAlterar,
                                 data=[cliente['cpf'], estruturaPagina])
        botaoRemover = ft.Button(content="Remover", icon=ft.Icons.REMOVE,
                                 on_click=models.verificarCondicoesDeExclusaoCliente,
                                 data=[cliente['cpf'], dialogo, estruturaPagina])
        linhaBotoes = ft.Row(controls=[botaoAlterar, botaoRemover], alignment=ft.MainAxisAlignment.END)

        clienteModelo = ctCliente.criarCliente(cliente['nome'], cliente['cpf'],
                                               cliente['email'], cliente['telefone'],
                                               linhaBotoes)
        listElementosColunaCliente.append(clienteModelo)

    colunaClientes = ft.Container(content=ft.Column(controls=listElementosColunaCliente,
                                                    horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                                                    scroll=ft.ScrollMode.AUTO),
                                  expand=True,
                                  padding=20)

    return colunaClientes

def telaClientes(estruturaPagina=None, mensagem=None):
    if mensagem == None:
        mensagem = ""

    telaLadoCadastro = ladoCadastro(estruturaPagina, mensagem)
    telaLadoLista = ladoLista(estruturaPagina)

    divisoriaVertical = ft.VerticalDivider(1, color=ft.Colors.GREY)

    divisaoTela = ft.Row(controls=[telaLadoCadastro, divisoriaVertical, telaLadoLista], expand=True)
    tela = ft.Container(content=divisaoTela, expand=True)

    return tela

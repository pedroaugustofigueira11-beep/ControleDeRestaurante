
import flet as ft

def home():
    LARANJA = "#FF8C00"
    FUNDO = "#111111"
    CARD = "#1C1C1C"
    BRANCO = "#FFFFFF"
    CINZA = "#A0A0A0"
    BORDA = "#303030"

    def menu_item(icone, texto, ativo=False):
        return ft.Container(
            content=ft.Row([
                ft.Icon(icone, color=LARANJA if ativo else CINZA, size=21),
                ft.Text(texto, color=BRANCO if ativo else CINZA, size=14)
            ], spacing=15),
            bgcolor="#30200F" if ativo else None,
            border_radius=10,
            padding=14
        )

    def card_indicador(icone, titulo, numero, descricao):
        return ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Container(
                        content=ft.Icon(icone, color=LARANJA, size=24),
                        bgcolor="#38230D", border_radius=10, padding=12
                    ),
                    ft.Icon(ft.Icons.TRENDING_UP, color=LARANJA, size=20)
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.Text(titulo, color=CINZA, size=13),
                ft.Text(str(numero), color=BRANCO, size=30, weight=ft.FontWeight.BOLD),
                ft.Text(descricao, color=LARANJA, size=11)
            ], spacing=12),
            bgcolor=CARD,
            border=ft.Border.all(1, BORDA),
            border_radius=14,
            padding=20,
            expand=True
        )

    def pedido_linha(numero, cliente, data, status):
        cores = {
            "Concluído": "#21C77A",
            "Em preparo": LARANJA,
            "Pendente": "#E6B422"
        }
        cor = cores.get(status, CINZA)

        return ft.Container(
            content=ft.Row([
                ft.Text(numero, color=LARANJA, size=13, width=85),
                ft.Text(cliente, color=BRANCO, size=13, expand=True),
                ft.Text(data, color=CINZA, size=12, width=90),
                ft.Container(
                    content=ft.Row([
                        ft.Container(width=7, height=7, bgcolor=cor, border_radius=10),
                        ft.Text(status, color=cor, size=11)
                    ], spacing=6),
                    width=115
                )
            ], vertical_alignment=ft.CrossAxisAlignment.CENTER),
            padding=15,
            border=ft.Border(
                bottom=ft.BorderSide(1, BORDA)
            )
        )

    # MENU LATERAL
    sidebar = ft.Container(
        width=225,
        bgcolor="#181818",
        padding=20,
        content=ft.Column([
            ft.Row([
                ft.Icon(ft.Icons.RESTAURANT, color=LARANJA, size=30),
                ft.Column([
                    ft.Text("FOOD", size=19, weight=ft.FontWeight.BOLD, color=BRANCO),
                    ft.Text("PAINEL ADMIN", size=9, color=LARANJA)
                ], spacing=0)
            ], spacing=10),

            ft.Container(height=20),
            ft.Text("MENU PRINCIPAL", color="#666666", size=10),
            menu_item(ft.Icons.HOME_ROUNDED, "Home", True),
            menu_item(ft.Icons.PEOPLE_ALT, "Clientes"),
            menu_item(ft.Icons.RECEIPT_LONG, "Pedidos"),

            ft.Container(expand=True),
            ft.Divider(color=BORDA),

            ft.Row([
                ft.Icon(ft.Icons.ACCOUNT_CIRCLE, color=LARANJA, size=35),
                ft.Column([
                    ft.Text("Administrador", color=BRANCO, size=12),
                    ft.Text("Gerenciador", color=CINZA, size=10)
                ], spacing=3)
            ], spacing=10)
        ], spacing=12, expand=True)
    )

    # CABEÇALHO
    cabecalho = ft.Row([
        ft.Column([
            ft.Text("HOME", color=BRANCO, size=25, weight=ft.FontWeight.BOLD),
            ft.Text("Visão geral do restaurante", color=CINZA, size=12)
        ], spacing=4),
        ft.Container(expand=True),
        ft.Container(
            content=ft.Row([
                ft.Icon(ft.Icons.CALENDAR_MONTH, color=LARANJA, size=17),
                ft.Text("Painel de controle", color=CINZA, size=12)
            ], spacing=8),
            bgcolor=CARD,
            padding=12,
            border_radius=10,
            border=ft.Border.all(1, BORDA)
        )
    ])

    # INDICADORES
    indicadores = ft.Row([
        card_indicador(ft.Icons.RECEIPT_LONG, "Pedidos realizados", 124, "Pedidos registrados"),
        card_indicador(ft.Icons.SCHEDULE, "Pedidos pendentes", 18, "Aguardando atendimento"),
        card_indicador(ft.Icons.CHECK_CIRCLE_OUTLINE, "Pedidos concluídos", 98, "Pedidos finalizados")
    ], spacing=15)

    # TABELA DE PEDIDOS
    tabela = ft.Container(
        bgcolor=CARD,
        border=ft.Border.all(1, BORDA),
        border_radius=14,
        padding=15,
        expand=True,
        content=ft.Column([
            ft.Column([
                ft.Text("Últimos Pedidos", color=BRANCO, size=19, weight=ft.FontWeight.BOLD),
                ft.Text("Acompanhe os pedidos recentes", color=CINZA, size=11)
            ], spacing=4),

            ft.Container(height=10),

            ft.Container(
                padding=15,
                content=ft.Row([
                    ft.Text("PEDIDO", color=CINZA, size=11, width=85),
                    ft.Text("CLIENTE", color=CINZA, size=11, expand=True),
                    ft.Text("DATA", color=CINZA, size=11, width=90),
                    ft.Text("STATUS", color=CINZA, size=11, width=115)
                ])
            ),

            pedido_linha("#0077", "Cleber", "06/10/26", "Concluído"),
            pedido_linha("#0078", "Mariana", "06/10/26", "Em preparo"),
            pedido_linha("#0079", "João Pedro", "06/10/26", "Pendente"),
            pedido_linha("#0080", "Ana Clara", "06/10/26", "Concluído"),
            pedido_linha("#0081", "Lucas", "06/10/26", "Em preparo")
        ], spacing=5)
    )

    # PAINEL DE STATUS
    status = ft.Container(
        width=210,
        bgcolor=CARD,
        border=ft.Border.all(1, BORDA),
        border_radius=14,
        padding=18,
        content=ft.Column([
            ft.Text("Status dos pedidos", color=BRANCO, size=14, weight=ft.FontWeight.BOLD),
            ft.Divider(color=BORDA),

            ft.Text("Concluídos", color=CINZA, size=12),
            ft.Row([
                ft.Container(width=8, height=8, bgcolor="#21C77A", border_radius=10),
                ft.Text("98 pedidos", color=BRANCO, size=13)
            ], spacing=8),

            ft.Container(height=8),
            ft.Text("Em preparo", color=CINZA, size=12),
            ft.Row([
                ft.Container(width=8, height=8, bgcolor=LARANJA, border_radius=10),
                ft.Text("8 pedidos", color=BRANCO, size=13)
            ], spacing=8),

            ft.Container(height=8),
            ft.Text("Pendentes", color=CINZA, size=12),
            ft.Row([
                ft.Container(width=8, height=8, bgcolor="#E6B422", border_radius=10),
                ft.Text("18 pedidos", color=BRANCO, size=13)
            ], spacing=8),

            ft.Container(height=15),
            ft.Text("Total de pedidos", color=CINZA, size=11),
            ft.Text("124", color=LARANJA, size=30, weight=ft.FontWeight.BOLD)
        ], spacing=12)
    )

    # CONTEÚDO PRINCIPAL
    conteudo = ft.Container(
        expand=True,
        bgcolor=FUNDO,
        padding=30,
        content=ft.Column([
            cabecalho,
            ft.Container(height=15),
            indicadores,
            ft.Container(height=15),
            ft.Row([
                tabela,
                status
            ], spacing=15, vertical_alignment=ft.CrossAxisAlignment.STRETCH, expand=True)
        ], spacing=10, expand=True, scroll=ft.ScrollMode.AUTO)
    )

    return ft.Row([
        sidebar,
        ft.VerticalDivider(width=1, color=BORDA),
        conteudo
    ], spacing=0, expand=True,
       vertical_alignment=ft.CrossAxisAlignment.STRETCH)

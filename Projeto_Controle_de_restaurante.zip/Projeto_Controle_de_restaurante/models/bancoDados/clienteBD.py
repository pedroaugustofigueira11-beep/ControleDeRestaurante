listaClientes = [
{
    "nome": "Maria Souza",
    "cpf": "12345678909",
    "email": "maria@email.com",
    "telefone": "81999990001",
},
{
    "nome": "João Pereira",
    "cpf": "98765432100",
    "email": "joao@email.com",
    "telefone": "81988880002",
},
{
    "nome": "Ana Lima",
    "cpf": "11144477735",
    "email": "ana@email.com",
    "telefone": "81977770003",
},
]

def encontrar_cliente(cpf):
    indice = 0
    for item in listaClientes:
        if item["cpf"] == cpf:
            return indice
        indice += 1

    return None

def pegarClientePeloCpf(cpf):
    for item in listaClientes:
        if item["cpf"] == cpf:
            return item

    return None

def pegarListaClientes():
    return listaClientes

def adicionarCliente(nome, cpf, email, telefone):
    cliente = {"nome": nome,
               "cpf": cpf,
               "email": email,
               "telefone": telefone
               }
    listaClientes.append(cliente)

def removerCliente(indiceExcluir):
    listaClientes.pop(indiceExcluir)

def alterarCliente(cpfAntigo, nome, cpfNovo, email, telefone):
    indiceAlterar = encontrar_cliente(cpfAntigo)
    clienteAlterado = {"nome": nome,
                       "cpf": cpfNovo,
                       "email": email,
                       "telefone": telefone
                       }
    listaClientes[indiceAlterar] = clienteAlterado

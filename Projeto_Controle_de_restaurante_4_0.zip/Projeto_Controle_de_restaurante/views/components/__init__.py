from views.components.campo import criarTitulo, criarCampo
from views.components.botao import criarBotao, criarBotaoAlterar, criarBotaoRemover, criarBotaoCancelar
from views.components.cliente import criarCliente
from views.components.prato import criarPrato
from views.components.pedido import criarPedido

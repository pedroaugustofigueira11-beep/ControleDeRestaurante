import flet as ft
import views.components.campo as ct
import models
import views.menu as menu

def voltarListaClientes(e: ft.Event[ft.Button]):
    estruturaPagina = e.control.data[0]
    menu.ao_mudar_aba(estruturaPagina, 0)

def telaAlterarCliente(estruturaPagina, cpfCliente):
    dadosCliente = models.pegarDadosClientePeloCpf(cpfCliente)

    titulo = ct.criarTitulo("Alterar Cliente")

    campoNome = ct.criarCampo("Nome", models.verificarNomeClienteDigitado, dadosCliente["nome"])
    campoCpf = ct.criarCampo("CPF (somente números)", models.verificarCpfDigitado, dadosCliente["cpf"])
    campoEmail = ct.criarCampo("E-mail", models.verificarEmailDigitado, dadosCliente["email"])
    campoTelefone = ct.criarCampo("Telefone com DDD", models.verificarTelefoneDigitado, dadosCliente["telefone"])

    textoMensagens = ft.Text("", size=18)

    botaoAlterar = ft.Button(content="Alterar", icon=ft.Icons.EDIT,
                             on_click=models.atualizarCliente,
                             data=[campoNome, campoCpf, campoEmail, campoTelefone,
                                   dadosCliente["cpf"], textoMensagens, estruturaPagina])

    botaoCancelar = ft.Button(content="Cancelar", icon=ft.Icons.CANCEL,
                              on_click=voltarListaClientes,
                              data=[estruturaPagina])

    linhaBotoes = ft.Row(controls=[botaoCancelar, botaoAlterar])

    linhaBotao = ft.Row(controls=[textoMensagens, linhaBotoes], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)

    conteudo = ft.Column(controls=[titulo, campoNome, campoCpf, campoEmail, campoTelefone, linhaBotao],
                         scroll=ft.ScrollMode.AUTO)

    return ft.Container(content=conteudo, expand=True, padding=20)

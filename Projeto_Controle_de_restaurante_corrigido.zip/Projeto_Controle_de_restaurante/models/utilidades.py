import flet as ft

VAZIO = "Não pode ficar vazio"
CATEGORIAS = ["Entrada", "Prato Principal", "Sobremesa", "Bebida"]

def somenteDigitos(texto):
    resultado = ""
    for letra in texto:
        if letra.isdigit():
            resultado += letra
    return resultado

def validarTexto(valor):
    if valor == None or valor.strip() == "":
        return VAZIO
    return ""

def validarCpf(valor):
    if validarTexto(valor) != "":
        return VAZIO
    if len(somenteDigitos(valor)) != 11:
        return "CPF precisa ter 11 números"
    return ""

def validarEmail(valor):
    if validarTexto(valor) != "":
        return VAZIO
    email = valor.strip()
    if " " in email or email.count("@") != 1:
        return "E-mail inválido"
    usuario, dominio = email.split("@")
    if usuario == "" or "." not in dominio or dominio.startswith(".") or dominio.endswith("."):
        return "E-mail inválido"
    return ""

def validarTelefone(valor):
    if validarTexto(valor) != "":
        return VAZIO
    tamanho = len(somenteDigitos(valor))
    if tamanho != 10 and tamanho != 11:
        return "Telefone precisa ter DDD + número"
    return ""

def validarCodigo(valor):
    if validarTexto(valor) != "":
        return VAZIO
    if not valor.strip().isdigit():
        return "Somente números"
    return ""

def converterNumero(valor):
    try:
        return float(valor.replace(",", "."))
    except:
        return None

def validarPreco(valor):
    if validarTexto(valor) != "":
        return VAZIO
    numero = converterNumero(valor)
    if numero == None or numero <= 0:
        return "Preço deve ser maior que zero"
    return ""

def validarTempo(valor):
    if validarTexto(valor) != "":
        return VAZIO
    if not valor.strip().isdigit() or int(valor) <= 0:
        return "Tempo em minutos (inteiro maior que zero)"
    return ""

def acharCategoria(valor):
    for categoria in CATEGORIAS:
        if categoria.lower() == valor.strip().lower():
            return categoria
    return None

def validarCategoria(valor):
    if validarTexto(valor) != "":
        return VAZIO
    if acharCategoria(valor) == None:
        return "Use: Entrada, Prato Principal, Sobremesa ou Bebida"
    return ""

# Pinta o campo conforme o resultado da validação.
# A mensagem de erro aparece no texto que fica em cima do campo (campo.data)
def verificarCampo(campo, erro):
    textoRotulo = campo.data

    if erro == "":
        campo.border_color = ft.Colors.GREEN
        campo.suffix_icon = ft.Icons.CHECK
        textoRotulo.value = textoRotulo.data
        textoRotulo.color = ft.Colors.WHITE
        return True

    if erro == VAZIO:
        campo.border_color = ft.Colors.YELLOW
        textoRotulo.color = ft.Colors.YELLOW
    else:
        campo.border_color = ft.Colors.RED
        textoRotulo.color = ft.Colors.RED
    campo.suffix_icon = None
    textoRotulo.value = erro
    return False

def formatarCpf(cpf):
    return f"{cpf[0:3]}.{cpf[3:6]}.{cpf[6:9]}-{cpf[9:11]}"

def formatarTelefone(telefone):
    if len(telefone) == 11:
        return f"({telefone[0:2]}) {telefone[2:7]}-{telefone[7:11]}"
    return f"({telefone[0:2]}) {telefone[2:6]}-{telefone[6:10]}"

def formatarPreco(preco):
    return f"R$ {preco:.2f}".replace(".", ",")

# Função de diálogo usada por todas as telas de exclusão
def fecharDialogo(e: ft.Event[ft.Button]):
    e.page.pop_dialog()
    e.page.update()

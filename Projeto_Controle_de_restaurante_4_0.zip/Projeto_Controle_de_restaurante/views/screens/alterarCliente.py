import flet as ft
import views.components.campo as ct
import views.components.botao as ctBotao
import models
import views.menu as menu

def voltarListaClientes(e: ft.Event[ft.Button]):
    estruturaPagina = e.control.data[0]
    menu.ao_mudar_aba(estruturaPagina, 0)

def telaAlterarCliente(estruturaPagina, cpfCliente):
    dadosCliente = models.pegarDadosClientePeloCpf(cpfCliente)

    titulo = ct.criarTitulo("Alterar Cliente")

    campoNome = ct.criarCampo("Nome", models.verificarNomeClienteDigitado, dadosCliente["nome"])
    campoCpf = ct.criarCampo("CPF (somente números)", models.verificarCpfClienteDigitado, dadosCliente["cpf"],
                            valorOriginal=dadosCliente["cpf"])
    campoEmail = ct.criarCampo("E-mail", models.verificarEmailDigitado, dadosCliente["email"])
    campoTelefone = ct.criarCampo("Telefone com DDD", models.verificarTelefoneDigitado, dadosCliente["telefone"])

    textoMensagens = ft.Text("", size=18)

    botaoAlterar = ctBotao.criarBotaoAlterar(models.atualizarCliente,
                                         [campoNome, campoCpf, campoEmail, campoTelefone,
                                          dadosCliente["cpf"], textoMensagens, estruturaPagina],
                                         grande=True)

    botaoCancelar = ctBotao.criarBotaoCancelar(voltarListaClientes,
                                          [estruturaPagina],
                                          grande=True)

    # Os dois botões têm expand=True: cada um ocupa metade da largura da tela
    linhaBotoes = ft.Row(controls=[botaoCancelar, botaoAlterar])
    linhaMensagem = ft.Row(controls=[textoMensagens])

    conteudo = ft.Column(controls=[titulo, ct.criarBlocoCampo(campoNome), ct.criarBlocoCampo(campoCpf),
                                   ct.criarBlocoCampo(campoEmail), ct.criarBlocoCampo(campoTelefone), linhaBotoes, linhaMensagem],
                         horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                         spacing=20,
                         scroll=ft.ScrollMode.AUTO)

    return ft.Container(content=conteudo, expand=True, padding=20)

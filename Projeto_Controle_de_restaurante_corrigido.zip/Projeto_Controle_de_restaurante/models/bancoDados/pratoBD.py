listaPratos = [
{
    "codigo": "1",
    "nome": "Cuscuz com charque",
    "categoria": "Prato Principal",
    "preco": 58.90,
    "tempoPreparo": 40,
},
{
    "codigo": "2",
    "nome": "Cocada de coco",
    "categoria": "Sobremesa",
    "preco": 6.00,
    "tempoPreparo": 5,
},
{
    "codigo": "3",
    "nome": "Suco de Caju",
    "categoria": "Bebida",
    "preco": 9.00,
    "tempoPreparo": 5,
},
{
    "codigo": "4",
    "nome": "Pão com manteiga",
    "categoria": "Entrada",
    "preco": 15.00,
    "tempoPreparo": 10,
},
]

def encontrar_prato(codigo):
    indice = 0
    for item in listaPratos:
        if item["codigo"] == codigo:
            return indice
        indice += 1

    return None

def pegarPratoPeloCodigo(codigo):
    for item in listaPratos:
        if item["codigo"] == codigo:
            return item

    return None

def pegarListaPratos():
    return listaPratos

def adicionarPrato(codigo, nome, categoria, preco, tempoPreparo):
    prato = {"codigo": codigo,
             "nome": nome,
             "categoria": categoria,
             "preco": preco,
             "tempoPreparo": tempoPreparo
             }
    listaPratos.append(prato)

def removerPrato(indiceExcluir):
    listaPratos.pop(indiceExcluir)

def alterarPrato(codigoAntigo, codigoNovo, nome, categoria, preco, tempoPreparo):
    indiceAlterar = encontrar_prato(codigoAntigo)
    pratoAlterado = {"codigo": codigoNovo,
                     "nome": nome,
                     "categoria": categoria,
                     "preco": preco,
                     "tempoPreparo": tempoPreparo
                     }
    listaPratos[indiceAlterar] = pratoAlterado

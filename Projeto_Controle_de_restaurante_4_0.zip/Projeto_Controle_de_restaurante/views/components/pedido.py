import flet as ft
import models.utilidades as ut
import views.components.campo as ct

def criarPedido(codigo, nomeCliente, cpf, itens, total, tempoPreparo, linhasBotao = None):
    topo = ft.Row(controls=[ct.criarAvatar(ft.Icons.RECEIPT_LONG),
                            ft.Text(f"Pedido nº {codigo}", size=22, weight=ft.FontWeight.BOLD, expand=True)],
                  spacing=15,
                  vertical_alignment=ft.CrossAxisAlignment.CENTER)

    listaElementos = [topo,
                      ct.criarLinhaInfo(ft.Icons.PERSON, f"{nomeCliente} (CPF {ut.formatarCpf(cpf)})")]

    for item in itens:
        subtotal = item["preco"] * item["quantidade"]
        listaElementos.append(ct.criarLinhaInfo(ft.Icons.RESTAURANT_MENU,
                                                f"{item['quantidade']}x {item['nome']} - {ut.formatarPreco(subtotal)}"))

    listaElementos.append(ct.criarLinhaInfo(ft.Icons.PAYMENTS, f"Total: {ut.formatarPreco(total)}", True))
    listaElementos.append(ct.criarLinhaInfo(ft.Icons.SCHEDULE, f"Preparo: até {tempoPreparo} min"))
    if linhasBotao != None:
        listaElementos.append(linhasBotao)

    return ct.criarCard(listaElementos)

# Linha de um prato dentro do carrinho (tela de cadastro)
def criarItemCarrinho(nomePrato, preco, tempoPreparo, botaoRemover):
    texto = ft.Text(f"{nomePrato} | {ut.formatarPreco(preco)} | {tempoPreparo} min", size=16, expand=True)
    linha = ft.Row(controls=[texto, botaoRemover],
                   vertical_alignment=ft.CrossAxisAlignment.CENTER)

    itemModelo = ft.Container(content=linha,
                              border=ft.Border.all(1, ft.Colors.GREY),
                              border_radius=10,
                              padding=10)

    return itemModelo

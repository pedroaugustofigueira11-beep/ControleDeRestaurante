import flet as ft

def criarTitulo(texto):
    titulo = ft.Container(content=ft.Text(texto, size=30, weight=ft.FontWeight.BOLD, color=ft.Colors.ORANGE),
                          alignment=ft.Alignment.CENTER)
    return titulo

# O texto que fica em cima do campo é guardado no "data" do campo.
# O "data" do próprio texto guarda o nome original, para voltar ao normal depois de um erro
def criarCampo(rotulo, aoDigitar=None, valor="", icone=None, dica=None):
    textoRotulo = ft.Text(rotulo, size=18, color=ft.Colors.WHITE, data=rotulo)
    campo = ft.TextField(value=valor,
                         data=textoRotulo,
                         prefix_icon=icone,
                         hint_text=dica,
                         border_color=ft.Colors.WHITE,
                         border_radius=10,
                         text_size=18,
                         on_change=aoDigitar)
    return campo

# Junta o texto de cima com o campo, para colocar na tela
def criarBlocoCampo(campo):
    bloco = ft.Column(controls=[campo.data, campo],
                      spacing=5,
                      horizontal_alignment=ft.CrossAxisAlignment.STRETCH)
    return bloco

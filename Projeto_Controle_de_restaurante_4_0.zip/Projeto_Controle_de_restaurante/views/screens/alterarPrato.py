import flet as ft
import views.components.campo as ct
import views.components.botao as ctBotao
import models
import views.menu as menu

def voltarListaPratos(e: ft.Event[ft.Button]):
    estruturaPagina = e.control.data[0]
    menu.ao_mudar_aba(estruturaPagina, 1)

def telaAlterarPrato(estruturaPagina, codigoPrato):
    dadosPrato = models.pegarDadosPratoPeloCodigo(codigoPrato)

    titulo = ct.criarTitulo("Alterar Prato")

    campoCodigo = ct.criarCampo("Código do prato", models.verificarCodigoPratoDigitado, dadosPrato["codigo"],
                                valorOriginal=dadosPrato["codigo"])
    campoNome = ct.criarCampo("Nome", models.verificarNomePratoDigitado, dadosPrato["nome"])
    campoCategoria = ct.criarCampo("Categoria (Entrada, Prato Principal, Sobremesa, Bebida)", models.verificarCategoriaDigitada, dadosPrato["categoria"])
    campoPreco = ct.criarCampo("Preço (ex: 25,90)", models.verificarPrecoDigitado, f"{dadosPrato['preco']:.2f}")
    campoTempo = ct.criarCampo("Tempo de preparo (minutos)", models.verificarTempoDigitado, f"{dadosPrato['tempoPreparo']}")

    textoMensagens = ft.Text("", size=18)

    botaoAlterar = ctBotao.criarBotaoAlterar(models.atualizarPrato,
                                         [campoCodigo, campoNome, campoCategoria, campoPreco, campoTempo,
                                          dadosPrato["codigo"], textoMensagens, estruturaPagina],
                                         grande=True)

    botaoCancelar = ctBotao.criarBotaoCancelar(voltarListaPratos,
                                          [estruturaPagina],
                                          grande=True)

    # Os dois botões têm expand=True: cada um ocupa metade da largura da tela
    linhaBotoes = ft.Row(controls=[botaoCancelar, botaoAlterar])
    linhaMensagem = ft.Row(controls=[textoMensagens])

    conteudo = ft.Column(controls=[titulo, ct.criarBlocoCampo(campoCodigo), ct.criarBlocoCampo(campoNome),
                                   ct.criarBlocoCampo(campoCategoria), ct.criarBlocoCampo(campoPreco),
                                   ct.criarBlocoCampo(campoTempo), linhaBotoes, linhaMensagem],
                         horizontal_alignment=ft.CrossAxisAlignment.STRETCH,
                         spacing=20,
                         scroll=ft.ScrollMode.AUTO)

    return ft.Container(content=conteudo, expand=True, padding=20)

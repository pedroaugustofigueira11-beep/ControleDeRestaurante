import flet as ft 

def telaInicial():
    Nomedatela = ft.Text("Home",
                         size = 30,
                         weight=ft.FontWeight.BOLD,
                         )
    NomeSecundario = ft.Text("Visão Geral do Restaurante",
                             size= 10,
                             weight=ft.FontWeight.BOLD)
    IconeDePrancheta = ft.Icon (icon=ft.Icons.TABLE_BAR)
    IconeDeRelogio = ft.Icon (icon=ft.Icons.LOCK_CLOCK)
    IconeDeCorreto = ft.Icon (icon=ft.Icons.CHECK_CIRCLE)
    PedidosRealizados = ft.Text("Pedidos Realizados")
    PedidosPendentes = ft.Text("Pedidos Pendentes")
    PedidosConcluidos = ft.Text("Pedidos Concluidos")

    ColunaDosPedidos = ft.Column (controls=[IconeDePrancheta, PedidosRealizados])
    ContainerDePedidos = ft.Container(content=ColunaDosPedidos)

    
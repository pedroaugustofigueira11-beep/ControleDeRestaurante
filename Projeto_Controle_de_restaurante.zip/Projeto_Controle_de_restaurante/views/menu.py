import flet as ft
import views.screens as sc

# Posição de cada aba (indice):
# 0 Clientes | 1 Pratos | 2 Pedidos
# Códigos extras (usados só pelos botões "Alterar"):
# 3 Alterar Cliente (aparece na aba 0) | 4 Alterar Prato (aparece na aba 1)
# O parâmetro "dado" leva o código do item a alterar ou uma mensagem de sucesso
def ao_mudar_aba(e :ft.Event[ft.Tabs], indice = None, dado = None):
    if indice == None:
        indice = e.control.selected_index
        estrutura_pagina = e.control.data
    else:
        estrutura_pagina = e

    if indice == 0:
        estrutura_pagina.controls[0] = sc.telaClientes(estrutura_pagina, dado)
    elif indice == 1:
        estrutura_pagina.controls[1] = sc.telaPratos(estrutura_pagina, dado)
    elif indice == 2:
        estrutura_pagina.controls[2] = sc.telaPedidos(estrutura_pagina, dado)
    elif indice == 3:
        estrutura_pagina.controls[0] = sc.telaAlterarCliente(estrutura_pagina, dado)
    elif indice == 4:
        estrutura_pagina.controls[1] = sc.telaAlterarPrato(estrutura_pagina, dado)

    estrutura_pagina.update()

def criarMenu():
    menu1 = ft.Tab(label="Clientes", icon= ft.Icons.PEOPLE)
    menu2 = ft.Tab(label="Pratos", icon= ft.Icons.RESTAURANT_MENU)
    menu3 = ft.Tab(label="Pedidos", icon= ft.Icons.RECEIPT_LONG)

    estruturaMenu = ft.TabBar(tabs=[menu1,menu2,menu3])

    tela1 = sc.telaClientes()
    tela2 = sc.telaPratos()
    tela3 = sc.telaPedidos()

    estruturaPagina = ft.TabBarView(controls=[tela1, tela2, tela3],
                                    expand=True)

    # Carrega as telas repassando a estruturaPagina
    estruturaPagina.controls[0] = sc.telaClientes(estruturaPagina)
    estruturaPagina.controls[1] = sc.telaPratos(estruturaPagina)
    estruturaPagina.controls[2] = sc.telaPedidos(estruturaPagina)

    estruturaMenuPagina = ft.Column(controls=[estruturaMenu,estruturaPagina],
                              expand=True)

    paginaComMenu = ft.Tabs(length=3,
                           expand=True,
                           content = estruturaMenuPagina,
                           on_change=ao_mudar_aba,
                           data= estruturaPagina
    )

    return paginaComMenu
